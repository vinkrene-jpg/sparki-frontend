# Sparki — Volledig gap-rapport t.o.v. Masterplan v2.41
**Datum:** 2026-07-27  
**Versie:** 1.0  
**Status:** Ter goedkeuring

---

## Correcties verwerkt

- **Stripe** is de betaalprovider (niet open).
- **OD_001 gesloten**: Go €9,99/mnd · €99,90/jr; Compleet €24,99/mnd · €249,90/jr.
- **OD_002 gesloten**: 14 dagen proef, geen betaalkaart vereist, geen automatische omzetting.
- **LIVE_CORE_PAGES_SHOW_MOCK_OR_FALLBACK_DATA**: status gewijzigd naar **HERKOMST NIET VOLLEDIG BEWEZEN** — gebruiker heeft aantoonbaar vreemde activiteiten/waarden gezien; code-grep en visuele scan sluiten runtime-, database- en cachecontaminatie niet uit.

---

## Deel 1 — Volledige inventarisatie per domein

### 1.1 Primaire routes (sporter)

| Route | Shell huidig | Switch? | Conformiteitsstatus |
|---|---|---|---|
| /vandaag | CommercialShell (via switch) | ✅ | **Gedeeltelijk conform** — leeg hoogte-blok aanwezig; desktop single-column |
| /train | CommercialShell (via switch) | ✅ | **Gedeeltelijk conform** — desktop single-column |
| /activiteiten | CommercialShell (via switch) | ✅ | **Gedeeltelijk conform** — HumorLine actief op CommercialShell-pagina |
| /lab (/analyse) | CommercialShell (via switch) | ✅ | **Gedeeltelijk conform** — desktop single-column |
| /meer | CommercialShell (via switch) | ✅ | **Gedeeltelijk conform** — hoofdpagina migrated, bestemmingen niet |
| /routes | ScreenShell | ❌ | **Niet conform** |
| /feed | ScreenShell | ❌ | **Niet conform** |

### 1.2 Alle routes achter Meer (sporter)

| Route | Label | Shell huidig | Gecontroleerd | Conformiteitsstatus |
|---|---|---|---|---|
| /you | Jij | ScreenShell | Volledig | **Niet conform** — shell, desktop layout, provenance |
| /lichaam | Lichaam | ScreenShell | Volledig | **Niet conform** — shell |
| /mechanieker | Mechanieker | ScreenShell | Volledig | **Niet conform** — shell, "Vraag Sparki"-knop in MaterialCoach |
| /samen | Samen | ScreenShell | Volledig | **Niet conform** — shell, HumorLine |
| /feed | Ontdekken | ScreenShell | Volledig | **Niet conform** — shell, HumorLine |
| /activiteiten | Activiteiten | CommercialShell | Volledig | **Gedeeltelijk conform** |
| /kalender | Kalender | ScreenShell | Volledig | **Niet conform** — shell |
| /kennis | Kennis | ScreenShell | Volledig | **Niet conform** — shell |
| /paspoort | Sportpaspoort | ScreenShell | Volledig | **Niet conform** — shell |
| /klimmen | Klimmen | ScreenShell | Volledig | **Niet conform** — shell |
| /geluid | Geluid | ScreenShell | Volledig | **Niet conform** — shell |
| /connect | Sparki Connect | ScreenShell | Volledig | **Niet conform** — shell |
| /support | Hulp & ondersteuning | ScreenShell | Volledig | **Niet conform** — shell |
| /races | Wedstrijd | ScreenShell | Volledig | **Niet conform** — shell |
| /journey | Journey | ScreenShell | Volledig | **Niet conform** — shell |

### 1.3 Drawers, modals, pop-ups en tabbladen

| Component | Trigger | Gecontroleerd | Conformiteitsstatus |
|---|---|---|---|
| AddTrainingModal | "+ training" button (Plan, Vandaag) | Volledig | **Gedeeltelijk conform** — geen zichtbaar succesresultaat na opslaan (onClose, geen toast/bevestiging) |
| WorkoutDetailDrawer | Trainingkaart aanklikken | Gedeeltelijk | **Niet volledig gecontroleerd** |
| FeedbackSheet | Na rit (workout feedback) | Gedeeltelijk | **Niet volledig gecontroleerd** |
| CheckinSheet | Lichaam > Check-in | Volledig | **Gedeeltelijk conform** — dag-type correct afgeleid |
| DayDetailDrawer | Kalender dag | Gedeeltelijk | **Niet volledig gecontroleerd** |
| SessionDetailDrawer | Activiteitendetail | Gedeeltelijk | **Gedeeltelijk conform** — HerkomstKnop aanwezig ✅ |
| RouteDetailDrawer | Route in bibliotheek | Gedeeltelijk | **Niet volledig gecontroleerd** |
| VoedingScreen (Sheet) | Lichaam > Voeding | Volledig | **Gedeeltelijk conform** — dag-type afgeleid ✅, provenance niet standaard ❌ |
| SparkiChatOverlay | Header (ScreenShell) | Volledig | **Niet conform** — "Vraag Sparki" zichtbaar als gepersonifieerde label |
| MainMenu | Hamburger (ScreenShell) | Volledig | **Niet conform** — "Vraag Sparki" prominent als menu-item |

### 1.4 Sporter-, coach-, ouder-, club- en beheeromgevingen

| Rol/omgeving | Routes | Shell | Gecontroleerd | Conformiteitsstatus |
|---|---|---|---|---|
| Sporter (primair) | /vandaag /train /activiteiten /meer /lab | Zie §1.1 | Volledig | Zie §1.1 |
| Coach — athlete plan | /coach/athletes/:id/plan | ScreenShell | Gedeeltelijk | **Niet conform** — shell |
| Coach — cockpit | /coach/athletes/:id/cockpit | ScreenShell | Gedeeltelijk | **Niet conform** — shell |
| Ouder | Via /vandaag + /feed + /invitations + /you | ScreenShell | Gedeeltelijk | **Niet conform** — shell op ouder-bestemmingen |
| Club — dashboard | /club | ScreenShell | Gedeeltelijk | **Niet conform** — shell |
| Club — beheer | /club/beheer | ScreenShell | Gedeeltelijk | **Niet conform** — shell; trial-datum correct afgeleid ✅ |
| Beheer (admin) | /admin, /admin/health/:key | Geen shell (intentioneel) | Gedeeltelijk | **Niet volledig gecontroleerd** — geen shell vereist ✅ |
| Uitnodigingen | /invitations, /invite/:token | ScreenShell | Gedeeltelijk | **Niet conform** — shell |
| Tester onboarding | /tester-qr, /welkom-tester | ScreenShell | Gedeeltelijk | **Niet conform** — shell |

### 1.5 Voeding

| Aspect | Status | Toelichting |
|---|---|---|
| Shell | ScreenShell (via /lichaam) | **Niet conform** |
| Dag-type hergebruik | ✅ Afgeleid via useAthleteDashboard + detectDayType | **Conform** — niet opnieuw gevraagd |
| Context-toelichting | ✅ CONTEXT_REASON ("Je hebt vandaag een wedstrijd") | **Conform** |
| Provenance-labels | ❌ "Voedingswaarde · schatting" en "Sparki-voedingskennis" | **Gedeeltelijk conform** — niet het standaard Gemeten/Berekend/Advies/Algemene richtlijn taxonomie |
| Generieke richtwaarden | ❌ Koolhydraatdoelen, proteïne etc. zonder "Algemene richtlijn"-label | **Niet conform** |
| Temperatuur | Niet gecontroleerd of temp hergebruikt wordt of irrelevant wordt getoond | **Niet volledig gecontroleerd** |

### 1.6 Materiaal / Mechanieker

| Aspect | Status | Toelichting |
|---|---|---|
| Shell (/mechanieker) | ScreenShell | **Niet conform** |
| "Vraag Sparki"-knop | ❌ material-coach.tsx:363 — zichtbare knoptekst | **Niet conform** — verboden per MP |
| Provenance (analyses) | Gedeeltelijk — MaterialCoach toont analyse-resultaten | **Niet volledig gecontroleerd** |
| Responsive | Niet gecontroleerd op ScreenShell | **Niet volledig gecontroleerd** |

### 1.7 Profiel (/you)

| Aspect | Status | Toelichting |
|---|---|---|
| Shell | ScreenShell | **Niet conform** |
| Data-herkomst | ✅ Echte data via hooks (observations, profiel, load) | **Conform** — geen mock-data gevonden |
| Provenance-labels | Gedeeltelijk — SportPassport heeft "Gemeten"/"Berekend" ✅; rest van /you niet volledig | **Gedeeltelijk conform** |
| Desktop layout | ScreenShell single-column | **Niet conform** |
| Communicatievorm | CoachAnalysisCard heeft coaching-alinea's op primaire laag | **Niet volledig gecontroleerd** |

### 1.8 Routes & navigatie (/routes)

| Aspect | Status |
|---|---|
| Shell | ScreenShell — **Niet conform** |
| RoutePanel, RouteLibrary, RouteDiscover, NavSettingsPanel | Aanwezig en functioneel |
| Responsive | Niet gecontroleerd op ScreenShell |
| HumorLine | Aanwezig in route-panel.tsx:3159 (lege staat) |

### 1.9 Wedstrijden (/races, /wedstrijd-room, /sprinten)

| Aspect | Status |
|---|---|
| Shell /races | ScreenShell — **Niet conform** |
| Shell /wedstrijd-room | ScreenShell — **Niet conform** |
| Shell /sprinten | ScreenShell — **Niet conform** |
| Data-vertrouwen | Niet volledig gecontroleerd |

### 1.10 Instellingen, privacy, support en koppelingen

| Route | Shell | Status |
|---|---|---|
| /support | ScreenShell | **Niet conform** |
| /connect | ScreenShell | **Niet conform** |
| /privacy | Geen shell (statisch) | **Conform** |
| /voorwaarden | Geen shell (statisch) | **Conform** |
| /geluid | ScreenShell | **Niet conform** |

### 1.11 Abonnementen, entitlements en upgradeflows

| Aspect | Status | Toelichting |
|---|---|---|
| Entitlements-fundament | Gedeeltelijk — admin sectie aanwezig, entitlement_mode in DB | **Gedeeltelijk conform** |
| Stripe integratie | ❌ Niet geïntegreerd — geen checkout, geen price IDs, geen webhook-verwerking | **Niet conform** |
| Trial flow (14d, geen kaart) | ❌ Niet geïmplementeerd voor individuele sporters | **Niet conform** |
| Upgrade-flow (Go → Compleet) | ❌ Niet geïmplementeerd | **Niet conform** |
| Grace period | ❌ Niet gedefinieerd of geïmplementeerd | **Niet conform** |
| BTW-inrichting (VAT OSS) | ❌ Niet geïmplementeerd | **Niet conform** |
| Stripe price IDs | ❌ Niet geconfigureerd | **Niet conform** |
| Club-abonnement via Stripe | Gedeeltelijk — trial-datum in DB, maar geen Stripe-koppeling | **Niet conform** |

---

## Deel 2 — Afwijkingsregister

**Ernstniveaus:** 🔴 Blokkerend · 🟠 Hoog · 🟡 Gemiddeld · 🔵 Laag

---

### Blok A — Schil & navigatie

#### A-01
- **Route(s):** /routes
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟠 Hoog (mobiele nav ontbreekt op nav-item 3)
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** DsMobileNav zichtbaar op /routes (390px); bestaande RoutePanel/RouteLibrary/RouteDiscover/NavSettingsPanel volledig bewaard; ScreenShell-pad intact wanneer vlag uit; nul horizontale overflow.
- **Wave:** W1

#### A-02
- **Route(s):** /feed
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟠 Hoog (desktop nav-item 5 landt op ScreenShell)
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell op /feed; bestaande feed-secties bewaard; ScreenShell-pad intact wanneer vlag uit; nul horizontale overflow.
- **Wave:** W1

#### A-03
- **Route(s):** /you
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟠 Hoog (kern-profilescherm zonder centrale schil)
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell op /you; alle bestaande hooks en profiel-secties bewaard; responsive 390/768/1440px.
- **Wave:** W3

#### A-04
- **Route(s):** /lichaam
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** A-03 (zelfde migratiepatroon)
- **Acceptatiecriteria:** CommercialShell; VoedingScreen, HealthFlowSection, CheckinSheet, MentalResilienceCard bewaard.
- **Wave:** W3

#### A-05
- **Route(s):** /mechanieker
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** COMM-01 (Vraag Sparki verwijderen)
- **Acceptatiecriteria:** CommercialShell; MaterialCoach, BikeGarage, MaterialTest, Bike3DWerkblad bewaard.
- **Wave:** W3

#### A-06
- **Route(s):** /races, /wedstrijd-room, /sprinten
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell op alle drie routes; bestaande wedstrijdlogica bewaard.
- **Wave:** W4

#### A-07
- **Route(s):** /kalender
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell; ThreeWeekPlan, race-koppeling bewaard.
- **Wave:** W4

#### A-08
- **Route(s):** /samen
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** COMM-04 (HumorLine)
- **Acceptatiecriteria:** CommercialShell; alle sociale secties bewaard; geen HumorLine op primaire laag.
- **Wave:** W4

#### A-09
- **Route(s):** /kennis
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell; kennis- en intel-secties bewaard.
- **Wave:** W4

#### A-10
- **Route(s):** /journey
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell; tijdlijn en wedstrijddossier bewaard.
- **Wave:** W4

#### A-11
- **Route(s):** /klimmen
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🔵 Laag
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell; klim-zoek en -detailweergave bewaard.
- **Wave:** W5

#### A-12
- **Route(s):** /paspoort
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🔵 Laag
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell; SportPassport-component met provenance-labels bewaard.
- **Wave:** W5

#### A-13
- **Route(s):** /geluid
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🔵 Laag
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell; geluidsregistratie en wekker-flow bewaard.
- **Wave:** W5

#### A-14
- **Route(s):** /connect
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld (koppelingsbeheer is vaak gebruikte functie)
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell; ConnectionsSection en ActivityImportPanel bewaard.
- **Wave:** W3

#### A-15
- **Route(s):** /support
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell; helpdesk en ticket-flow bewaard.
- **Wave:** W5

#### A-16
- **Route(s):** /profiel/:clerkId
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🔵 Laag (secundaire route, sociaal profiel)
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell; privacy-gefilterde weergave bewaard.
- **Wave:** W5

#### A-17
- **Route(s):** /club, /club/beheer
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** BILL-01 (Stripe club-abonnement)
- **Acceptatiecriteria:** CommercialShell; clubdashboard en beheersecties bewaard.
- **Wave:** W5 (partieel — na Stripe beslissing)

#### A-18
- **Route(s):** /coach/athletes/:id/plan, /coach/athletes/:id/cockpit
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell; coach-plan en cockpit-secties volledig bewaard.
- **Wave:** W5

#### A-19
- **Route(s):** /invitations, /invite/:token, /tester-qr, /welkom-tester
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🔵 Laag
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** CommercialShell of neutrale shell afhankelijk van context; bestaande flows bewaard.
- **Wave:** W5

#### A-20 — Nav-asymmetrie desktop vs. mobiel
- **Route(s):** Alle (commercial-shell.ts)
- **Centraal/paginaspecifiek:** Centraal
- **Ernst:** 🟡 Gemiddeld
- **Toelichting:** Desktop nav item 5 = "Ontdekken" (/feed); mobiele nav item 5 = "Meer" (/meer). Keuze niet gedocumenteerd als MP-conform.
- **Afhankelijkheden:** A-02
- **Acceptatiecriteria:** Keuze expliciet vastgelegd in MP of gewijzigd; geen onbedoelde asymmetrie.
- **Wave:** W1 (beslissing vastleggen, geen code)

---

### Blok B — Communicatiestandaard

#### COMM-01 — Vraag Sparki in MaterialCoach
- **Route(s):** /mechanieker (material-coach.tsx:363)
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🔴 Blokkerend (MP known defect + expliciet verbod)
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** Knoptekst "Vraag Sparki" vervangen door functionele actienaam; SparkiChatOverlay blijft beschikbaar via neutraal icoon zonder personificerende tekst; geen zichtbare "Vraag Sparki"-tekst op /mechanieker.
- **Wave:** W2

#### COMM-02 — Vraag Sparki in MainMenu
- **Route(s):** Alle ScreenShell-pagina's (main-menu.tsx:136,148)
- **Centraal/paginaspecifiek:** Centraal
- **Ernst:** 🔴 Blokkerend (expliciet verbod MP)
- **Afhankelijkheden:** COMM-01
- **Acceptatiecriteria:** "Vraag Sparki" als zichtbaar menu-item verwijderd; chat-toegang behouden via icoon zonder personificerende tekst.
- **Wave:** W2

#### COMM-03 — HumorLine op CommercialShell (Activiteiten)
- **Route(s):** /activiteiten (core-activiteiten.tsx:143)
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟠 Hoog (migrated CommercialShell-pagina, humor active_now: false per MP)
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** HumorLine verwijderd van lege-staat Activiteiten; eerlijke lege staat.
- **Wave:** W2

#### COMM-04 — HumorLine op primaire laag (Feed en Samen)
- **Route(s):** /feed (feed.tsx:155), /samen (samen.tsx:610)
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟠 Hoog
- **Afhankelijkheden:** A-02 (Feed migratie)
- **Acceptatiecriteria:** HumorLine verwijderd van lege staat op beide pagina's; eerlijke lege staat.
- **Wave:** W1 (feed als onderdeel van migratie), W4 (samen)

#### COMM-05 — AddTrainingModal: geen zichtbaar resultaat
- **Route(s):** /train, /vandaag (add-training.tsx)
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟠 Hoog (MP known defect)
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** Na succesvol opslaan: modal sluit én zichtbare bevestiging (inline succes-state of toast); bij fout: zichtbare foutmelding.
- **Wave:** W2

#### COMM-06 — Leeg hoogte-blok onder "Hoe voel je je?"
- **Route(s):** /vandaag (commercial-shell.tsx, CommercialToday)
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟠 Hoog (MP known defect)
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** Geen onzichtbaar hoogte-blok zichtbaar op 390×844; nul lege ruimte onder de check-in/voel-sectie bij alle dag-types.
- **Wave:** W2

#### COMM-07 — Provenance-labels niet consistent
- **Route(s):** /lichaam (VoedingScreen), /you, diverse
- **Centraal/paginaspecifiek:** Centraal (ontbrekend gedeeld systeem)
- **Ernst:** 🟡 Gemiddeld
- **Toelichting:** Voeding gebruikt "Voedingswaarde · schatting" en "Sparki-voedingskennis" i.p.v. standaard taxonomie (Gemeten / Berekend / Advies / Algemene richtlijn). SportPassport heeft Gemeten/Berekend ✅; rest inconsistent.
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** Voeding-richtwaarden gelabeld als "Algemene richtlijn"; koachconclusies als "Advies"; meetwaarden als "Gemeten" of "Berekend".
- **Wave:** W3

#### COMM-08 — HumorLine secundaire oppervlakken
- **Route(s):** three-week-plan.tsx (laadstatus), bike-garage.tsx, route-panel.tsx, training-day-home.tsx
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** HumorLine vervangen door neutrale lege-staat tekst op alle genoemde locaties.
- **Wave:** W4

---

### Blok C — Data-trust

#### DTRUST-01 — Runtime herkomst niet bewezen
- **Route(s):** Alle gepubliceerde routes
- **Centraal/paginaspecifiek:** Centraal
- **Ernst:** 🔴 Blokkerend
- **Toelichting:** Code-grep toont geen hardgecodeerde mock-data in productie-JSX. Oorzaak van door gebruiker waargenomen vreemde activiteiten/waarden niet vastgesteld. Mogelijke oorzaken: dev-seed rijen in productie-DB, cross-account DB-fout, stale cache, FK-collision bij accountkoppeling.
- **Afhankelijkheden:** geen (vereist DB-analyse, geen code-wijziging vooraf)
- **Acceptatiecriteria:** Aantoonbare herkomst van ALLE zichtbare data op de vijf kernschermen voor de ingelogde testgebruiker via DB-query + provenance-endpoint; of oorzaak geïdentificeerd en hersteld.
- **Wave:** W0 (vóór alle andere waves — diagnose, geen code)

#### DTRUST-02 — Stale cache niet gemarkeerd
- **Route(s):** Alle routes met gecachte data
- **Centraal/paginaspecifiek:** Centraal
- **Ernst:** 🟡 Gemiddeld
- **Toelichting:** MP vereist dat stale cache als stale gemarkeerd wordt. Niet gecontroleerd of huidig gedrag hieraan voldoet.
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** Stale data toont expliciete indicator of wordt stil ververst; geen stale data als vers gepresenteerd.
- **Wave:** Parked — aparte beoordeling vereist

---

### Blok D — Desktop layout

#### DESK-01 — Desktop single-column op alle CommercialShell-pagina's
- **Route(s):** /vandaag, /train, /activiteiten, /meer, /lab
- **Centraal/paginaspecifiek:** Centraal (CommercialShell + CommercialToday)
- **Ernst:** 🟠 Hoog (MP verbiedt NO_MOBILE_NARROW_COLUMN_USED_AS_DESKTOP_LAYOUT)
- **Toelichting:** Sidebar 56px aanwezig ✅. Content area max-w-3xl gecentreerd — single column. MP vereist via Figma-node 43:6: MULTI_COLUMN_INFORMATION_HIERARCHY, EXTRA_WIDTH_USED_FOR_PARALLEL_CONTEXT, NO_STRETCHED_MOBILE_CARD_STACK.
- **Afhankelijkheden:** Figma-node 43:6 beschikbaar als referentie (te bevestigen)
- **Acceptatiecriteria:** Desktop 1440×900 toont twee informatiezones naast elkaar op CommercialToday; geen gestapelde mobiele kaartkolom; mobiele layout 390px ongewijzigd; alle data-flows ongewijzigd.
- **Wave:** W2 (Vandaag als referentie-implementatie)

---

### Blok E — Voeding

#### VOEDING-01 — Generieke richtwaarden zonder standaard label
- **Route(s):** /lichaam → VoedingScreen
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** COMM-07
- **Acceptatiecriteria:** Koolhydraat-, proteïne- en vetrichtwaarden gelabeld als "Algemene richtlijn"; "Sparki-voedingskennis" alleen als bron-attributie.
- **Wave:** W3

#### VOEDING-02 — Temperatuur-check
- **Route(s):** /lichaam → VoedingScreen, /vandaag
- **Centraal/paginaspecifiek:** Paginaspecifiek
- **Ernst:** 🟡 Gemiddeld
- **Toelichting:** Niet volledig gecontroleerd of temperatuur wordt gevraagd/getoond wanneer niet relevant.
- **Afhankelijkheden:** geen
- **Acceptatiecriteria:** Temperatuur alleen getoond/gevraagd wanneer aantoonbaar relevant voor de huidige context.
- **Wave:** W3 (na gerichte beoordeling)

---

### Blok F — Billing & entitlements

#### BILL-01 — Geen Stripe integratie
- **Route(s):** Geen bestaande route (nieuw te bouwen)
- **Centraal/paginaspecifiek:** Centraal
- **Ernst:** 🔴 Blokkerend voor commerciële lancering
- **Toelichting:** Stripe niet geïntegreerd. Geen checkout-flow, geen price IDs, geen webhook-verwerking voor individuele sporters.
- **Afhankelijkheden:** Stripe price IDs; entitlements-schema uitbreiden
- **Acceptatiecriteria:** Werkende checkout voor Go en Compleet (test-modus); 14-daagse trial zonder betaalkaart; na trial geen automatische omzetting; webhook verwerkt betaalgebeurtenissen correct.
- **Wave:** W6

#### BILL-02 — Trial flow niet geïmplementeerd
- **Route(s):** Nieuw
- **Ernst:** 🔴 Blokkerend voor commerciële lancering
- **Afhankelijkheden:** BILL-01
- **Acceptatiecriteria:** Gebruiker start 14-daagse Compleet-proef zonder betaalkaart; na afloop terug naar Go-tier; geen automatische omzetting.
- **Wave:** W6

#### BILL-03 — Upgrade-flow niet geïmplementeerd
- **Route(s):** Nieuw (vanuit /meer of /you)
- **Ernst:** 🟠 Hoog
- **Afhankelijkheden:** BILL-01, BILL-02
- **Acceptatiecriteria:** Sporter kan vanuit de app upgraden van Go naar Compleet; entitlement direct actief na betaling.
- **Wave:** W6

#### BILL-04 — Grace period niet gedefinieerd of geïmplementeerd
- **Route(s):** Centraal (server-side)
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** BILL-01
- **Acceptatiecriteria:** Beslissing over grace period vastgelegd; implementatie in entitlements-laag.
- **Wave:** W6 (na beslissing)

#### BILL-05 — BTW-inrichting niet geïmplementeerd
- **Route(s):** Server-side + Stripe
- **Ernst:** 🟠 Hoog (EU-lancering vereist)
- **Afhankelijkheden:** BILL-01
- **Acceptatiecriteria:** BTW-configuratie per land; NL BTW correct (21%); OSS-registratie-pad gedocumenteerd.
- **Wave:** W6

#### BILL-06 — Club-abonnement niet aan Stripe gekoppeld
- **Route(s):** /club/beheer
- **Ernst:** 🟡 Gemiddeld
- **Afhankelijkheden:** BILL-01
- **Acceptatiecriteria:** Club-proefperiode en betaling via Stripe; trial-datumveld gevuld via Stripe.
- **Wave:** W6

---

## Deel 3 — Herstelbacklog en wave-planning

| Wave | Naam | Afwijkingen | Reden volgorde |
|---|---|---|---|
| **W0** | Data-trust diagnose | DTRUST-01 | Vóór alles — oorzaak onbekende data identificeren; geen code |
| **W1** | Rijden + Ontdekken naar CommercialShell | A-01, A-02, A-20, COMM-04 (feed) | Navigatiecontinuïteit herstellen op alle 5 nav-items |
| **W2** | Communicatiestandaard + desktop referentie | COMM-01, COMM-02, COMM-03, COMM-05, COMM-06, DESK-01 | Verboden patronen wegnemen; desktop referentie-implementatie |
| **W3** | Jij + Lichaam + Connect | A-03, A-04, A-05, A-14, COMM-07, VOEDING-01, VOEDING-02 | Kern-profileschermen en voeding |
| **W4** | Wedstrijd + Kalender + Samen + Kennis + Journey + COMM-08 | A-06, A-07, A-08, A-09, A-10, COMM-04 (samen), COMM-08 | Secondaire domein-migraties |
| **W5** | Overige schermen | A-11, A-12, A-13, A-15, A-16, A-17, A-18, A-19 | Klimmen, Paspoort, Geluid, Support, Profiel, Club, Coach, Onboarding |
| **W6** | Stripe billing | BILL-01 t/m BILL-06 | Vereist Stripe setup; commerciële lanceringsgate |
| **Parked** | Stale cache labeling | DTRUST-02 | Aparte beoordeling vereist |
| **Parked** | i18n-fundering | — | MP status: PAUSED; NL-NL enige actieve locale |

### Volledigheidscontrole — alle ID's in een wave

✅ A-01 → W1 | ✅ A-02 → W1 | ✅ A-03 → W3 | ✅ A-04 → W3 | ✅ A-05 → W3
✅ A-06 → W4 | ✅ A-07 → W4 | ✅ A-08 → W4 | ✅ A-09 → W4 | ✅ A-10 → W4
✅ A-11 → W5 | ✅ A-12 → W5 | ✅ A-13 → W5 | ✅ A-14 → W3 | ✅ A-15 → W5
✅ A-16 → W5 | ✅ A-17 → W5 | ✅ A-18 → W5 | ✅ A-19 → W5 | ✅ A-20 → W1

✅ COMM-01 → W2 | ✅ COMM-02 → W2 | ✅ COMM-03 → W2 | ✅ COMM-04 → W1+W4
✅ COMM-05 → W2 | ✅ COMM-06 → W2 | ✅ COMM-07 → W3 | ✅ COMM-08 → W4

✅ DTRUST-01 → W0 | ✅ DTRUST-02 → Parked

✅ DESK-01 → W2

✅ VOEDING-01 → W3 | ✅ VOEDING-02 → W3

✅ BILL-01 → W6 | ✅ BILL-02 → W6 | ✅ BILL-03 → W6
✅ BILL-04 → W6 | ✅ BILL-05 → W6 | ✅ BILL-06 → W6

---

## Deel 4 — Open vragen voor akkoord

1. **W0 (DTRUST-01):** Productie-DB read-only toegang nodig voor herkomst-diagnose. Doen in productieomgeving of eerst beperken tot ontwikkelomgeving?

2. **A-20 (nav-asymmetrie):** Desktop toont item 5 als "Ontdekken" (/feed), mobiel als "Meer" (/meer). Is dit de gewenste keuze, of moet desktop ook "Meer" tonen?

