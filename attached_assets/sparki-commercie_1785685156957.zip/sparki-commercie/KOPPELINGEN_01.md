# KOPPELINGEN_01 — Concurrentie, instapscherm en koppelingen

**Type:** analyse plus bouwopdracht voor Replit
**Gemeten op:** main `e67ccc40`, 2 augustus 2026
**Aanleiding:** athletedata.health, bekeken op 2 augustus 2026

---

## Deel 1 — Wat athletedata is, en waarom het ertoe doet

Dit is de eerste aanbieder die dicht bij Sparki's Compleet-belofte komt: een coach die je trainingsdata leest en je vertelt wat je vandaag moet doen.

Maar de as is een andere. **Zij vragen je nergens over te stappen.** Ze bouwen geen app waar je heen moet; ze lezen wat je al gebruikt en sturen je een bericht in WhatsApp, iMessage of Telegram. Hun eigen woorden: een coach die elke app leest waarmee je traint, en jou als eerste een bericht stuurt.

**Wat zij hebben en Sparki niet:**

- veertien of meer koppelingen, inclusief Whoop, Oura, Withings, MyFitnessPal, Cronometer, Hevy, Zwift, Rouvy, TrainerRoad, TrainingPeaks en intervals.icu
- aflevering via een kanaal dat de gebruiker toch al open heeft — geen app om te openen, geen melding om weg te tikken
- expliciete samenvoeging van dubbele gegevens: koppel gerust twee bronnen die hetzelfde meten, wij ontdubbelen
- een gratis proefperiode van zeven dagen die pas start wanneer de coach erom vraagt, niet bij aanmelden

**Wat Sparki heeft en zij niet:**

- routes en navigatie — zij hebben geen enkele kaartfunctie
- club, jeugd en ouders, met toestemming en veiligheid
- team en wedstrijddag
- een eigen omgeving waarin het werk gebeurt

Kort: **zij zijn een coach zonder product eromheen; Sparki is een product met een coach erin.** Dat is verdedigbaar, maar het betekent wel dat hun instapdrempel lager is dan die van Sparki, en dat ze op de coachbelofte alleen sneller kunnen zijn.

**Wat hieruit te leren valt, zonder hun model te kopiëren:** het aantal koppelingen is bij hen het verkoopargument, niet een technisch detail. Bij Sparki staat het koppelscherm nu diep weggestopt in de instellingen.

---

## Deel 2 — Het instapscherm

Hun instapscherm is los van de concurrentie het bekijken waard, en het past bij wat er voor Sparki al is besloten.

`KOP-01` — **Drie stappen bovenaan met een voortgangsbalk, die verdwijnen zodra je klaar bent.** Niet een permanente lijst met vinkjes die blijft staan als herinnering aan wat je niet deed. Bij hen: koppel je bronnen · verbind je kanaal · start je proefperiode.

`KOP-02` — **Per stap één zin over waaróm.** "Hoe meer hij leest, hoe beter hij coacht." Geen instructie zonder reden.

`KOP-03` — **Koppelingen in categorieën met een zoekveld.** Bij hen: activiteit · herstel · voeding · context. Voor Sparki ligt voor de hand: ritten · herstel · materiaal · voeding.

`KOP-04` — **Per koppeling in één regel wat hij oplevert**, niet wat hij is. "Ritten, slaap en accuniveau" zegt meer dan "Garmin Connect".

`KOP-05` — **Eerlijke toestanden per koppeling.** Bij hen staat bij Whoop dat alle plaatsen bezet zijn met een knop om bericht te krijgen, en bij TrainingPeaks en Zwift staat "alleen lezen". Dat is precies de eerlijkheid die voor Sparki al is vastgelegd: geen functie tonen alsof hij werkt.

`KOP-06` — **Aanbevolen koppelingen zijn gemarkeerd.** Een nieuwe gebruiker weet niet welke van de veertien hij nodig heeft.

Dit instapscherm geldt voor Sparki op telefoon én desktop, uit dezelfde code, conform `SPARKI_TELEFOON_UX_01` v1.1.

`KOP-06a` — **Het aantal koppelingen hoort ook op de marketingsite.** Bij de vergelijkbare aanbieder is het een verkoopargument op de openbare pagina, niet iets dat je pas na aanmelden ontdekt. Zie `MARKETINGSITE_01`.

---

## Deel 3 — Koppelingen: wat Sparki heeft

**Gemeten in de code, aantal bestanden waarin de provider voorkomt:**

| Provider | Bestanden | Oordeel |
|---|---|---|
| Strava | 54 | volwaardig |
| Garmin | 35 | volwaardig |
| Wahoo | 22 | substantieel |
| Oura | 13 | substantieel |
| intervals.icu | 10 | aanwezig |
| Polar | 5 | aanzet |
| Zwift | 3 | aanzet |
| Suunto · Coros · Whoop | 1 | naam genoemd, verder niets |
| TrainerRoad | 0 | bestaat niet |

Er is een koppelscherm: `pages/sparki-connect.tsx`.

`KOP-07` — **Eerste taak: stel per provider de werkelijke stand vast.** Aantal bestanden is een indicatie, geen bewijs. Lever per provider: werkt de koppeling, wat haalt hij op, is het lezen of ook schrijven, en wat is er nodig om hem af te maken.

`KOP-08` — **Maak af wat half af is voordat je iets nieuws begint.** Polar en Zwift staan op een aanzet; Suunto, Coros en Whoop zijn alleen een naam. Een half werkende koppeling is schadelijker dan een ontbrekende, want de gebruiker denkt dat zijn gegevens binnenkomen.

`KOP-09` — **Volgorde voor uitbreiding, met reden:**

1. **Whoop en Withings** — herstel en gewicht. Sparki's begeleidingslaag vraagt om slaap en herstel, en heeft die vandaag alleen via Oura.
2. **Polar en Coros** afmaken — na Garmin en Wahoo de meest gebruikte fietscomputers in Europa.
3. **intervals.icu** afmaken — de gebruikers daarvan zijn precies de renners die Compleet zouden kopen.
4. **Zwift en Rouvy** — binnentrainingen, relevant in de winter en nu een gat in de historie.
5. **MyFitnessPal of Cronometer** — pas nadat de voedingslaag af is; eerder heeft het geen bestemming.

`KOP-10` — **Dubbele bronnen.** Er is al besloten hoe Sparki hiermee omgaat: de gebruiker stelt bij de eerste koppeling in welke bron wint, en daarna wordt een afwijking stil verwerkt. Zet die keuze in het koppelscherm zelf, op het moment van koppelen — niet weggestopt in de instellingen.

`KOP-11` — **Het koppelscherm komt uit de instellingen naar voren.** Bij een aanbieder die hierop concurreert is dit een verkoopargument; bij Sparki staat het nu diep weggestopt. Het hoort bij de eerste drie stappen na aanmelden.

---

## Wat er niet bij hoort

Geen aflevering van coachadvies via WhatsApp of Telegram — dat is hun model, niet dat van Sparki, en het botst met de besloten communicatieregels en de jeugdgrens · geen nieuwe koppeling zonder dat de vorige aantoonbaar werkt · geen provider tonen die niet werkt zonder dat erbij staat wat er aan de hand is.

---

## Acceptatie

Per provider is vastgesteld of hij werkt en wat hij ophaalt. Een half werkende koppeling is óf afgemaakt óf zichtbaar gemarkeerd als niet beschikbaar. Het koppelscherm toont categorieën, een zoekveld, per koppeling wat hij oplevert, en welke worden aanbevolen. De drie instapstappen verdwijnen zodra ze gedaan zijn.

Lever de bewijsbundel op een vaste SHA, met de schermen op telefoon en desktop.
