# COMMERCIE_01 — Prijzenpagina's en het upgradepad

**Type:** bouwopdracht voor Replit
**Gemeten op:** main `e67ccc40`, 2 augustus 2026
**Besluiten:** René, 1 en 2 augustus 2026
**Geldt onder:** `SPARKI_TELEFOON_UX_01` v1.1 — elk scherm hier is zowel telefoon als desktop

---

## Waarom

De eerste release is een test **mét betalende klanten**. Vandaag kan niemand zien wat de pakketten kosten en niemand kan upgraden.

**Gemeten:** er bestaat wél een `/abonnement`-pagina en `/facturatie` (trainerfacturatie). Er is **geen** prijzen- of vergelijkingspagina en **geen** upgrade- of downgradepad.

---

## 1. Twee volledige ingangen

`COM-01` — De openbare kant van Sparki wordt **gesplitst in twee ingangen**, naar het model van TrainingPeaks: **voor sporters** en **voor professionals**. Niet alleen twee prijzentabellen, maar twee wegen naar binnen, elk met een eigen aanmelding, een eigen prijzenpagina en eigen uitleg.

Reden: het is een andere koper met een ander bezwaar. Een renner vergelijkt drie prijzen. Een clubvoorzitter wil weten wat het zijn vereniging kost en of het bestuur akkoord gaat — die leest een andere tekst, en die schrikt van een tabel waar €149 naast €2,99 staat.

`COM-01a` — **Beide ingangen zijn te bekijken zonder account.** Iemand moet kunnen zien wat het kost voordat hij zich aanmeldt.

`COM-01b` — **Eén account, twee deuren.** De splitsing zit in de openbare kant, niet in het account. Een trainer die zelf ook rijdt, meldt zich één keer aan en heeft beide rollen — hij hoeft niet te kiezen en hij maakt geen tweede account. De ingang bepaalt alleen waar hij binnenkomt en welke teksten hij leest.

`COM-01c` — Vanaf elke ingang is de andere bereikbaar, onderaan de pagina: twee kolommen naast elkaar.

`COM-01d` — **Onder elke ingang staat een eigen pagina per doelgroep** — renner, renner met plan, ouder, zelfstandige trainer, club, clubtrainer, team, ploegleider, staf en specialisten. Die pagina's staan beschreven in `MARKETINGSITE_01`; dit document gaat alleen over de prijzen en het upgradepad.

---

## 0. Open punt — moet vast vóór publicatie

**De prijs van Compleet is €9,99 per maand en er is geen jaarprijs vastgesteld.** Alle andere pakketten hebben er wel een. Zolang dat bedrag ontbreekt kan de maand- en jaarschakelaar bij Compleet niets tonen.

Bouw de pagina met de prijs als lege configuratiewaarde en meld het als openstaand; dit blokkeert de bouw niet, wel de publicatie.

`COM-02` — **Ingang 1 — voor sporters.** Gratis, Go en Compleet naast elkaar.

| | Gratis | Go | Compleet |
|---|---|---|---|
| Prijs | €0 | €2,99 p/mnd · €29,90 p/jr | €9,99 p/mnd |
| Routes | 8 per maand, 3 bewaard, 30 dagen | onbeperkt | onbeperkt |
| Navigatie | volledig, met spraak | volledig | volledig |
| Wandelen | ja, uit hetzelfde potje | ja | ja |
| Bibliotheek | eigen routes zien en verwijderen | zoeken, sorteren, onbeperkt bewaren | idem |
| Historie | 30 dagen | 12 maanden | 12 maanden |
| Ritanalyse | basis | volledig, met trends | volledig |
| Koppelingen | Strava basis | Strava volledig, Garmin direct | idem |
| Materiaal | — | registratie en onderhoud | idem |
| Advies | — | één dag terug, één dag vooruit | trainingsplan, coach, periodisering, herstel |
| Wedstrijd | — | — | wedstrijdbegeleiding |
| Vrienden op de kaart | — | — | ja |

`COM-03` — **Ingang 2 — voor professionals.** Trainer, Club en Team.

| | Sparki Trainer | Club | Team |
|---|---|---|---|
| Prijs | €99 p/mnd · €990 p/jr, tot 25 sporters | **gratis** | €149 p/mnd · €1.490 p/jr |
| Daarboven | €179 p/mnd tot 50 · daarna €9,90 per sporter | — | — |
| Voor wie | zelfstandige trainer | vereniging met leden en jeugd | ploeg die wedstrijden rijdt |
| Bevat | training, analyse **en voeding** · klantbeheer · facturatie met btw en creditnota's | leden, groepen, seizoenen, rollen, jeugd en ouders, communicatie, VOG | alles van Club plus de wedstrijdoperatie: bezetting, dagschema, vervoer, materiaal, taken, noodinformatie |

`COM-04` — Op de clubpagina hoort de **clubafname** uitgelegd: een club kan Compleet afnemen voor haar leden, per lid gekozen, met staffelkorting in vaste tredes en maandelijkse facturatie.

`COM-05` — Geen kunstmatige urgentie. Geen aftellende klok, geen "nog maar even". Eerst wat je krijgt, dan wat het kost.

---

## 1a. Wat er op de prijzenpagina's staat, naast de tabel

`COM-05a` — **Maand- en jaarschakelaar** boven de tabel, met het besparingspercentage erbij. Beide prijzen zijn besloten; ze staan nu nergens naast elkaar. Bereken het percentage uit de bedragen, zet het niet vast in de tekst.

`COM-05b` — **Kostencalculator op de professionele ingang.** De bezoeker vult in hoeveel sporters hij begeleidt en ziet zijn maandbedrag. Dit volgt de besloten staffel: tot 25 sporters €99 p/mnd · tot 50 €179 p/mnd · daarboven €9,90 per sporter per maand, vast bedrag zonder verdere korting, ingaand bij sporter 51.

Dit is het sterkste onderdeel van de pagina. Bij twintig sporters betaalt een trainer bij Sparki €99 alles inbegrepen; bij de gevestigde aanbieder loopt hetzelfde geval op tot ruim het dubbele, en betaalt de sporter daar vaak ook nog zelf. **Laat de bezoeker dat zelf uitrekenen in plaats van het te beweren.** Geen vergelijking met een concurrent op de pagina — alleen het eigen bedrag.

`COM-05c` — **Vergelijking gegroepeerd op thema**, niet één lange lijst. Voor de sporter: Routes en navigatie · Ritten en analyse · Training en begeleiding · Wedstrijd · Samen. Voor de professional: Sporters en groepen · Training en analyse · Organisatie · Wedstrijdoperatie · Zakelijk.

`COM-05d` — **Veelgestelde vragen onder de prijzen**, uitklapbaar. Minimaal deze vier, want dit zijn de bezwaren op het moment van betalen: is er korting bij jaarbetaling · is er een proefperiode en hoe lang · wat gebeurt er als ik opzeg · zijn er kosten die ik nu niet zie. De antwoorden volgen de besloten regels: rechten lopen door tot de einddatum, materiaal wordt afgeschermd en niet verwijderd, en alles komt terug bij hervatting.

---

## 1b. Openbare kennisartikelen — apart, maar hier hoort de verwijzing

`COM-05e` — Het grootste kanaal van de vergelijkbare aanbieder is geen prijzenpagina maar een **openbare artikelenhub**. Bij Sparki staan al **297 kennisitems** in het systeem, maar die zijn uitsluitend binnen de app zichtbaar.

`COM-05f` — **Dit valt buiten `COMMERCIE_01` en wordt een eigen opdracht**, want het raakt `KENNIS_01`: wie schrijft, bronvermelding, jeugdmarkering en publicatiestatus zijn daar al belegd. Bouw hier alleen de verwijzing: vanaf beide ingangen een zichtbare weg naar de kennisartikelen.

`COM-05g` — Wat wel meteen vastligt voor die latere opdracht: de artikelen zijn **openbaar leesbaar zonder account** — dat is het hele punt van het kanaal. De kennisartikelen binnen de app blijven bij Compleet horen; wat openbaar komt is een selectie, geen dump van alle 297.

---

## 2. Het upgradepad — hier gebeurt het echt

`COM-06` — Een prijzenpagina is waar mensen het overwégen. Overstappen gebeurt op het moment dat ze een grens raken. Bouw het upgradepad **daar**:

- bij de **negende route** van de maand — besloten: eerlijke melding, dan het aanbod
- bij de **vierde bewaarde route** op Gratis
- bij de **betaalmuur op analyse**, waar nu al een knop naar het abonnement staat
- bij de **rustige verwijzing naar Go** in de routebibliotheek, die al bestaat

`COM-07` — Elk van die punten leidt naar hetzelfde afrekenpad, niet naar de prijzenpagina met de vraag om opnieuw te kiezen. De gebruiker weet al wat hij wil; hij raakte net de grens.

`COM-08` — Volgorde in de melding: eerst wat er aan de hand is, dan wat het kost om verder te kunnen. Nooit andersom.

---

## 3. Afrekenen

`COM-09` — Stripe, maandelijks of jaarlijks. Btw conform het land van de klant. Bevestiging per mail met de factuur.

`COM-10` — **Proefperiode van zeven dagen** op Go, zoals besloten.

`COM-11` — Betaalstromen komen nooit onbedoeld bij Sparki terecht — dat is een harde stop uit de uitvoeringsregel. Bij de trainer loopt de klantbetaling via zijn eigen aangesloten account.

---

## 4. Abonnementbeheer

`COM-12` — De bestaande `/abonnement`-pagina wordt de plek waar de gebruiker ziet: welk pakket hij heeft, tot wanneer, wat hij betaalt, welke betaalmethode, en zijn facturen.

`COM-13` — Van daaruit kan hij **wijzigen en opzeggen**. Bij opzeggen: rechten lopen door tot de einddatum, geen terugbetaling naar rato.

`COM-14` — Bij terugvallen naar Gratis wordt materiaal afgeschermd, niet verwijderd, en de gebruiker **ziet dát er iets is afgeschermd**. Gaat hij later weer betalen, dan komt alles terug — niet alleen het laatste jaar.

`COM-15` — Betaalt zijn club voor hem, dan ziet hij dat hier, en kan hij het weigeren. Weigeren telt als zelf opzeggen.

---

## 5. Clubafname voor de clubbeheerder

`COM-16` — Een eigen scherm in de clubomgeving: per lid kiezen of Compleet wordt afgenomen, het aantal afgenomen plaatsen, de staffeltrede waarin de club zit, en de maandfactuur.

`COM-17` — **De club ziet alleen aantallen** — niet welke leden Compleet gebruiken en niet wie heeft geweigerd. Dat is een besluit en het wordt serverzijdig afgedwongen, niet in het scherm verborgen.

`COM-18` — Voor een jeugdlid moet de ouder akkoord geven; de club kan dat niet zelfstandig.

---

## 6. Telefoon en desktop

`COM-19` — Alle schermen hierboven werken op beide, uit dezelfde code, en tonen hetzelfde. Een prijzentabel op de telefoon is geen versmalde desktoptabel: op klein scherm één pakket tegelijk met een keuzestrook erboven, niet drie kolommen naast elkaar.

`COM-20` — Op de prijzenpagina staat de belangrijkste informatie — wat je krijgt en wat het kost — in beeld zonder te scrollen. De volledige vergelijking mag eronder.

---

## 7. Directe herstelgronden

`COM-21` — Een prijs die in de code staat in plaats van in de configuratie.
`COM-22` — Een prijzenpagina die inloggen vereist.
`COM-23` — Een upgradeknop die naar een prijzenpagina leidt in plaats van naar afrekenen.
`COM-24` — Een club die kan zien welke leden Compleet gebruiken of geweigerd hebben.
`COM-25` — Een betaalstroom die bij Sparki terechtkomt waar hij bij de trainer hoort.
`COM-26` — Kunstmatige urgentie of een aftelklok.
`COM-26a` — Een besparingspercentage dat als tekst is ingetypt in plaats van uit de bedragen berekend.
`COM-26b` — Een kostencalculator die een ander bedrag toont dan er daadwerkelijk wordt gefactureerd.
`COM-26c` — Een vergelijking met een concurrent bij naam op de pagina.
`COM-26d` — Kennisartikelen die achter inloggen zitten waar ze openbaar horen te zijn.
`COM-27` — Drie kolommen naast elkaar op een telefoonscherm.
`COM-28` — Afgeschermd materiaal dat verdwijnt zonder dat de gebruiker ziet dat het bestaat.

---

## 8. Acceptatie

Iemand zonder account opent de prijzenpagina op zijn telefoon, ziet wat Go kost en wat hij ervoor krijgt, meldt zich aan en rekent af. Een gratis gebruiker raakt bij zijn negende route de grens, krijgt een eerlijke melding met het aanbod, en staat twee tikken later op het afrekenscherm. Een clubbeheerder opent zijn afnamescherm, kiest tien leden, ziet zijn trede en zijn maandbedrag — en ziet nergens wie er gebruikmaakt of geweigerd heeft.

Lever de bewijsbundel op een vaste SHA, met de schermen op telefoon en desktop erbij.
