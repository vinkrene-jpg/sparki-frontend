# MARKETINGSITE_01 — De openbare kant van Sparki

**Type:** bouwopdracht voor Replit
**Gemeten op:** main `e67ccc40`, 2 augustus 2026
**Besluit:** René, 2 augustus 2026
**Verhouding:** `COMMERCIE_01` beschrijft de prijzen en het upgradepad; dit document beschrijft waar die pagina's staan en hoe ze eruitzien.

---

## Waarom

**Gemeten: Sparki heeft geen openbare kant.** Er is geen enkele pagina die iemand zonder account kan bekijken. Wie over Sparki hoort, kan nergens heen.

De aanleiding is een vergelijking met athletedata.health: grote productbeelden, veel ruimte, één boodschap per schermvulling, en rustig scrollen. Dat wekt vertrouwen. Naast zo'n pagina voelt Sparki klein — maar dat is een vergelijking tussen hun etalage en onze werkplaats. Deze opdracht bouwt de etalage.

---

## 1. Los van de app

`MKT-01` — De marketingsite staat **los van de applicatie**. Andere eisen: hij moet in een seconde laden op een telefoon met slecht bereik, vindbaar zijn in zoekmachines, en zonder inloggen werken.

`MKT-02` — Dit botst niet met het besluit dat app en browser uit één codebasis komen. Dat besluit gaat over het **product**. De site is geen product; hij verkoopt het.

`MKT-03` — Statisch gegenereerd. Geen ingelogde toestand, geen gebruikersgegevens, geen verbinding met de productiedatabase. De enige koppeling is de knop die naar aanmelden in de app leidt.

`MKT-04` — **Prijzen komen uit één bron.** Ze worden niet overgetypt op de site. Loopt de site uit de pas met de app, dan verkoop je iets anders dan je levert. Lever dit als één configuratiebestand dat beide kanten lezen, of als een gegenereerd bestand bij het bouwen.

---

## 2. Twee ingangen, met een eigen pagina per doelgroep

`MKT-05` — De site heeft twee wegen naar binnen: **voor sporters** en **voor professionals**. Elk met een eigen aanmeldknop, eigen prijzenpagina en eigen uitleg.

`MKT-06` — Onderaan elke pagina staan beide kolommen naast elkaar, zodat je altijd kunt oversteken.

`MKT-07` — **Eén account, twee deuren.** De splitsing zit uitsluitend in de site. Wie zich aanmeldt komt in hetzelfde Sparki terecht; er is geen keuze bij aanmelden en er ontstaat geen tweede soort account.

`MKT-07a` — **Onder elke ingang staat een eigen pagina per doelgroep.** Eis: iedere doelgroep moet een pagina vinden waarvan hij denkt *"dit is de app die ontbreekt, die wil ik"*. Een algemene pagina waarin iedereen zich een beetje herkent, overtuigt niemand.

**Onder "voor sporters":**

| Pagina | Voor wie | Kern van de belofte |
|---|---|---|
| De renner | Gratis en Go | een routeplanner die weet wat voor rit je wilt maken |
| De renner met een plan | Compleet | begeleiding die uitlegt waarom, en een route die bij je training past |
| De ouder | ouders van jeugdleden | je kind fietst bij een club en jij ziet wat er gebeurt |

**Onder "voor professionals":**

| Pagina | Voor wie | Kern van de belofte |
|---|---|---|
| De zelfstandige trainer | trainer met eigen klanten | training, analyse, voeding én facturatie in één, voor één prijs |
| De club | bestuur en clubbeheer | leden, seizoenen, jeugd en toestemmingen geregeld — gratis |
| De clubtrainer | trainers en hoofdtrainers binnen een club | je groep in één beeld, en zien wie aandacht nodig heeft |
| Het team | teammanager | de hele wedstrijdoperatie in één plan |
| De ploegleider | ploegleider | zaterdag geregeld: bezetting, dagschema, vervoer, materiaal, taken |
| De staf | mechanieker, soigneur, medische staf | jouw deel van het plan, op je telefoon, ook zonder bereik |
| De specialisten | voedingsdeskundige | jouw analyse en plannen, gekoppeld aan de sporter, zonder dat de trainer je dossier inziet |

`MKT-07b` — **Niet elke doelgroep is een koper, en dat bepaalt de knop.** Een mechanieker koopt Sparki niet; het team koopt het.

- **Koperspagina's** (renner, trainer, club, team) eindigen in *begin nu* of *bekijk de prijzen*.
- **Gebruikerspagina's** (clubtrainer, ploegleider, staf, specialisten) eindigen in *stuur dit naar je club* of *stuur dit naar je ploegleider* — met een knop die de pagina deelt.

Die pagina's zijn niet minder waardevol: ze overtuigen de mensen die de koper moeten overhalen, en ze laten diepte zien die geen concurrent heeft.

`MKT-07c` — **Geen pagina gericht op minderjarigen.** Jeugd wordt bereikt via de ouderpagina en via de club. Wervende teksten richting kinderen horen niet op deze site.

`MKT-07d` — Elke doelgroeppagina heeft dezelfde opbouw: één zin die de belofte draagt · een echt scherm dat díé rol gebruikt · drie dingen die alleen Sparki doet · de juiste knop. Niet langer dan dat.

---

## 3. Wat "groot voelen" veroorzaakt

Dit is geen smaak maar vakwerk. Vijf dingen, in volgorde van effect:

`MKT-08` — **Grote echte productbeelden op ware grootte.** Een telefoon met een echt Sparki-scherm erin, niet een icoon of een illustratie. Bij de concurrent is dat een gesprek met de coach; bij Sparki ligt de routeplanner met de kaart voor de hand.

`MKT-09` — **Ruimte.** Weinig per schermvulling, veel wit eromheen. Een volle pagina leest als een handleiding; een lege leest als een product.

`MKT-10` — **Eén boodschap per schermvulling, in grote letters.** Niet drie voordelen naast elkaar, maar één zin die je onthoudt, en daaronder twee regels uitleg.

`MKT-11` — **Rustige beweging bij het scrollen.** Elementen die binnenkomen, niet springen. Volledig bruikbaar met beweging uitgeschakeld; dat is een bestaande regel.

`MKT-12` — **De sfeerbeelden die er al liggen.** Er zijn vijfenzestig beelden die nu alleen in lege toestanden worden gebruikt. Die dragen de site. Regel blijft: nooit gebruiken om een specifieke route te duiden — daarvoor een kaartuitsnede of hoogteprofiel.

---

## 4. Wat er niet op mag

`MKT-13` — **Sociaal bewijs komt er pas op zodra het er is.** Gebruikersaantallen, clublogo's en citaten zijn sterk en horen er absoluut op — maar pas wanneer er klanten zijn om ze aan te ontlenen. Tot die tijd draagt het product zichzelf.

`MKT-14` — Wat het nu draagt: echte schermen, echte grafieken met echte ritten, en beloftes die Sparki als enige kan maken. Dat is scherper dan een getal, en het houdt stand.

`MKT-15` — **Geen concurrent bij naam.** Geen vergelijkingstabel met andere aanbieders. Dat maakt hen de maatstaf.

`MKT-16` — Geen kunstmatige urgentie, geen aftelklok, geen "nog maar even".

---

## 5. Wat er wel op staat

**Boven aan de sporterkant:** één zin die zegt wat Sparki doet, een echt scherm van de routeplanner, en één knop.

**Daaronder, per schermvulling één ding:** de route die weet wat je moet trainen · je ritten terugzien · de begeleiding die uitlegt waarom · wandelen · wat het kost.

**Boven aan de professionele kant:** één zin voor de trainer of de club, een echt scherm van de groepsweergave of de wedstrijddag, en één knop.

**Daaronder:** je sporters en groepen · de wedstrijddag in één plan · jeugd en ouders geregeld · facturatie · wat het kost, met de kostencalculator.

**Op beide:** de veelgestelde vragen, en de weg naar de kennisartikelen zodra die openbaar zijn.

---

## 6. Eisen

`MKT-17` — Laadtijd onder één seconde op een gemiddelde telefoonverbinding, gemeten en gerapporteerd — geen indruk.

`MKT-18` — Vindbaar: elke pagina heeft een eigen titel en beschrijving, en de site is leesbaar zonder JavaScript.

`MKT-19` — Werkt op telefoon en desktop, en de telefoonversie is geen versmalde desktopversie. Op klein scherm één pakket tegelijk in de prijzentabel, niet drie kolommen.

`MKT-20` — Toegankelijk: leesbaar contrast, werkt met een schermlezer, volledig bruikbaar met beweging uit.

---

## 7. Directe herstelgronden

`MKT-22` — Een prijs die op de site anders is dan in de app.
`MKT-23` — Een concurrent bij naam.
`MKT-24` — Een illustratie of icoon waar een echt productscherm hoort.
`MKT-25` — Drie prijskolommen naast elkaar op een telefoonscherm.
`MKT-26` — Een pagina die inloggen vereist.
`MKT-27` — Een sfeerbeeld dat een specifieke route moet voorstellen.
`MKT-28` — Een doelgroeppagina zonder een echt scherm van díé rol.
`MKT-29` — Een koopknop op een pagina voor iemand die niet koopt.
`MKT-30` — Een wervende pagina gericht op minderjarigen.

---

## 8. Wat René moet leveren

**De domeinnaam.** Zonder die keuze kan de site nergens staan. Dat is het enige dat Replit niet zelf kan invullen.

---

## 9. Acceptatie

Iemand die de naam Sparki hoort, zoekt hem op, komt op een pagina die in een seconde laadt, ziet binnen één schermvulling wat het is en voor wie, en kan doorklikken naar de prijzen van zijn eigen doelgroep. Alles wat er staat is aantoonbaar het product.

Lever de bewijsbundel met de gemeten laadtijd en de pagina's op telefoon en desktop.
