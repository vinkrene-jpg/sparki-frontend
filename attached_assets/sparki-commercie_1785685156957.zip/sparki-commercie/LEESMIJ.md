# Sparki — de commerciële laag

Drie stukken, nagekeken tegen main op 2 augustus 2026. Ze horen bij elkaar en overlappen niet.

**MARKETINGSITE_01** — de openbare kant. Een aparte site, los van de app, met twee ingangen (sporters en professionals) en daaronder een eigen pagina per doelgroep: renner, renner met plan, ouder, zelfstandige trainer, club, clubtrainer, team, ploegleider, staf en specialisten. Wat René nog moet leveren: de domeinnaam.

**COMMERCIE_01** — de prijzen en het upgradepad. Twee prijzenpagina's, de kostencalculator voor de trainer, de maand-jaarschakelaar, de veelgestelde vragen, afrekenen, abonnementbeheer en het clubafnamescherm. Eén open punt: de jaarprijs van Compleet is nooit vastgesteld.

**KOPPELINGEN_01** — concurrentieanalyse van athletedata.health, het instapscherm met de drie stappen, en de stand van de koppelingen per provider met de volgorde voor uitbreiding.

## Volgorde

Deze drie komen ná `GRATIS_A_TOT_Z_01`. Die keten is de testpoort van René en gaat voor.

Binnen deze drie: eerst de marketingsite (er is vandaag geen enkele openbare pagina), dan de prijzen en het upgradepad, dan de koppelingen.
