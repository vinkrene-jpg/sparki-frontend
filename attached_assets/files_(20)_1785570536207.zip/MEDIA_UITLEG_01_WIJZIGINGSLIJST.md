# MEDIA_UITLEG_01 — WIJZIGINGSLIJST v1.1

**Deel 21 van 21** · gerichte eindcorrectie, 1 augustus 2026
Uitsluitend de acht opgedragen correcties verwerkt. Verder niets aangeraakt. Geen nieuwe CMP-, PAT-, MTS- of MUX-codes. Geen code. Master Plan niet aangeraakt.

---

## 1. F0 Mirror-poort

| Document | Wijziging |
|---|---|
| Replit-opdrachten | F0 veld "Mirror-toets" vervangen door een **formele Mirror-poort op een vaste SHA**: vijf steekproeven "aanwezig" tegen code en repository · drie steekproeven "afwezig" waarbij Mirror **zelf zoekt** · de plaats van Hulp & ondersteuning zelf vastgesteld · de bestaande motion-, media-, toegankelijkheids- en helptechniek zelf vastgesteld. Claude-controle alleen is niet voldoende. |
| Mirror-toetsen | F0 herschreven van volledigheidscontrole naar zes genummerde toetspunten, met de regel dat F1 pas start na `F0 MIRROR_PROVEN`. Afkeurgrond toegevoegd: een "afwezig" dat bij zelf zoeken wél blijkt te bestaan. |
| Afhankelijkheden | F1-voorwaarde gewijzigd van "F0 opgeleverd" naar **`F0 MIRROR_PROVEN`**, eigenaar F0 en Mirror. |

## 2. F3 geen PARTIAL-doorgang

| Document | Wijziging |
|---|---|
| Replit-opdrachten | F3 krijgt een veld **Blokkerende input**: één technisch geschikt testmediabestand met bron, maker, licentie, gebruiksrecht en versie, **onafhankelijk van definitieve `KENNIS_01`-inhoud**. Zonder dat asset blijft F3 `OPEN`. De eerdere `PARTIAL`-formulering in het opleverrapport is geschrapt. |
| Mirror-toetsen | F3 scenario 14 toegevoegd (rechtenbewijs testasset compleet) plus de regel: geen `PARTIAL`-doorgang, F4 wacht op **volledig** `F3 MIRROR_PROVEN`. |
| Afhankelijkheden | F3-regel van "gedeeltelijk" naar **blokkerend**; F4-regel naar "volledig `F3 MIRROR_PROVEN`"; de algemene `PARTIAL`-regel krijgt F3 als expliciete uitzondering. |
| Mediarechten | nieuw hoofdstuk 4 "Testasset voor F3"; volgende hoofdstukken doorgenummerd. |
| Open afhankelijkheden | O-3 gesplitst: **O-3** rechtenvrij testasset (blokkeert F3 volledig) en **O-3b** mediabron voor echte inhoud (blokkeert publicatie). |
| Pilotadvies | de zin over doorgaan met een `PARTIAL` afspeelpad is vervangen. |

## 3. CMP-44 alleen niet-acuut

| Document | Wijziging |
|---|---|
| Replit-opdrachten | F7-scope beperkt tot **uitsluitend de niet-acute** melding. Toegevoegd: geen nieuw acute-meldingenregime bouwen; acute veiligheids- en medische meldingen blijven in hun **bestaande veiligheidslaag**. Vier toetspunten toegevoegd die F7 wél moet aantonen. Bewijsveld aangepast. |
| Componentcontracten | het blok "Acuut regime — apart pad" vervangen door "Acute en medische meldingen — buiten dit component", met de vier toetspunten. |
| Mirror-toetsen | F7-kop en scenario 5 herschreven; Mirror toetst met een **echte** acute melding, niet met een nagebouwde. |
| Jeugd en veiligheid | slotzin van hoofdstuk 3 vervangen: het acute regime wordt hier **getoetst, niet gebouwd**. |
| Synchronisatiepatch | nieuw besluit **MED-B4** ter registratie. |

## 4. Geen placeholdercontent in Preview of productie

| Document | Wijziging |
|---|---|
| Replit-opdrachten | veld "Niet bouwen" van de uitlegflowfase uitgebreid met het verbod op placeholdervideo, mockuitleg en nagebootste Sparki-inhoud in Preview of productie; nieuw veld **Testfixture**: afgesloten, niet publiceerbaar, niet bereikbaar voor gewone gebruikers, geen fictieve persoonlijke data. |
| Mirror-toetsen | scenario 12 toegevoegd plus aanvullende afkeurgronden. |
| README | regel **R-B** uitgebreid met het fixtureverbod. |

## 5. Mobiele data — definitief vastgelegd

| Document | Wijziging |
|---|---|
| Architectuur | D-5 vervangen door vijf harde regels: standaard geen videodownload · bewust **per apparaat** toe te staan · later weer uit te schakelen · poster en volledige tekstvariant blijven beschikbaar · geen stille download of prefetch. |
| Componentcontracten | CMP-41 veld "Mobiel" gelijkgetrokken. |
| Open afhankelijkheden | **O-8 gesloten** — geen open punt meer. |
| Synchronisatiepatch | nieuw besluit **MED-B3** ter registratie. |

## 6. Batterij- en datameting

| Document | Wijziging |
|---|---|
| Replit-opdrachten | F0 krijgt **Meetopstelling vaststellen**: welke fysieke iPhone en Android als referentietoestel dienen en welke meetmiddelen beschikbaar zijn. De regressiefase meet vooraf vastgelegde scenario's: schermtijd · gedownloade data · CPU/GPU-belasting waar meetbaar · batterijverbruik over een vaste testduur · animatie aan versus uit · video versus tekstvariant. |
| Mirror-toetsen | meetblok toegevoegd aan de regressiefase; **afkeur bij een subjectief oordeel "lijkt soepel"**. Het verbruikspunt verwijst nu naar de referentietoestellen in plaats van "een gemiddeld toestel". |
| Afhankelijkheden | F0-regel toegevoegd voor referentietoestellen en meetmiddelen. |
| Open afhankelijkheden | **O-13** toegevoegd. |

## 7. Pilotbeschrijving

| Document | Wijziging |
|---|---|
| Pilotadvies | verduidelijkt: **"training voltooid" is de samengestelde eindpilot**, niet de eerste codefase. De dieptekaartfase blijft de eerste codefase voor de zichtbare pilot; de coachmelding wordt pas toegevoegd nadat die fase **zelfstandig** `MIRROR_PROVEN` is. Echte adviesgrond blijft verplicht — geen demo-advies. |

## 8. Consistentie

| Document | Wijziging |
|---|---|
| README | versie v1.1; documentindex uitgebreid met deze wijzigingslijst; nieuwe algemene regel **R-C: geen halve doorgang**. |
| Synchronisatiepatch | besluitregister van twee naar vier besluiten; afbouwmatrix: coachmelding gemarkeerd als "uitsluitend niet-acuut". |

---

## Let op — één nummeringsverschil

De correctieopdracht spreekt over **F4** (uitlegflow), **F6** (coachmelding) en **F9** (metingen). Dat is de nummering van het ingetrokken 5-delige concept. In het definitieve pakket — met de fase-indeling die je in de definitieve opdracht zelf hebt voorgeschreven — zijn dat:

| Opdracht noemt | Definitieve fase | Onderwerp |
|---|---|---|
| F4 | **F5** | uitlegflow (CMP-42) |
| F6 | **F7** | coachmelding (CMP-44) |
| F9 | **F10** | regressie en metingen |

Ik heb de correcties toegepast op het **onderwerp**, niet op het nummer, en de nummering van het definitieve pakket ongewijzigd gelaten. Wil je toch terug naar de oude nummering, dan is dat een aparte hernummeringsronde over alle documenten — geen gerichte correctie.

---

*Deel 21 van 21.*
