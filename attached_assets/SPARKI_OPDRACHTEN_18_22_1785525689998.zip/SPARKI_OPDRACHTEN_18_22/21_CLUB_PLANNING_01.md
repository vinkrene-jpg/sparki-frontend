# BOUWOPDRACHT — CLUBPLANNING EN AANWEZIGHEID (CLUB_PLANNING_01)

**Uitvoerder:** Replit  
**Startcommit:** actuele `main`

## Doel
Maak een complete club- en teamkalender waarmee trainingen, wedstrijden, vergaderingen en materiaalafspraken gepland, gewijzigd, bevestigd en gevolgd worden.

## Buiten scope
- Geen algemene personeelsplanning.
- Geen nieuwe kalenderprovider; bestaande kalender- en notificatieservices hergebruiken.

## Productregels
1. Rollen bepalen wie mag plannen, wijzigen en aanwezigheid zien.
2. Sporters/ouders kunnen aanmelden, afmelden en waar toegestaan reden toevoegen.
3. Wijzigingen leiden tot betrouwbare notificaties zonder dubbele berichten.
4. Jeugdactiviteiten volgen oudertoestemming.
5. Tijdzone is expliciet en server-side consistent.

## Te bouwen
- Activiteitstypen: training, wedstrijd, vergadering, materiaal, overig.
- Team/clubdoelgroep, locatie, tijd, herhaling, capaciteit, wachtlijst.
- Aanmelden, afmelden, aanwezig, afwezig, onbekend.
- Ouderbevestiging voor jeugd waar nodig.
- Traineroverzicht en aanwezigheidsrapport.
- Wijzigingshistorie en auditlog.
- Persoonlijke kalenderkoppeling/export via bestaande services.
- Conflictcontrole en duidelijke foutmeldingen.

## Tests
1. Trainer plant training voor eigen team.
2. Onbevoegde gebruiker kan niet wijzigen.
3. Herhaling maakt juiste reeks.
4. Wijziging verstuurt één melding.
5. Aanmelden/afmelden werkt.
6. Wachtlijst schuift correct door.
7. Ouder bevestigt jeugddeelname.
8. Tijdzonegrens correct.
9. Kalenderexport bevat juiste gegevens.
10. Conflicten worden getoond, niet stilzwijgend overschreven.
11. Verwijderen bewaart audittrail.
12. Teamdata lekt niet.
13. Mobiel en desktop gelijkwaardig.
14. Providerfout veroorzaakt geen dubbele events.
15. Geen mockaanwezigheid.

## Acceptatiecriteria
Een club kan een seizoen plannen, deelnemers volgen en wijzigingen communiceren zonder databaseingrepen; rechten en tijdzones kloppen; tests groen.

## Bewijs
Start/eind-SHA, gewijzigde bestanden, kalender-API-contract, notificatiebewijs, tijdzonetests, screenshots en exitcodes.

## Mirror-toets
Mirror toetst planning, wijziging, herhaling, aanwezigheid, jeugd/ouder, wachtlijst, tijdzone, notificaties, API-omzeiling en teamisolatie.
