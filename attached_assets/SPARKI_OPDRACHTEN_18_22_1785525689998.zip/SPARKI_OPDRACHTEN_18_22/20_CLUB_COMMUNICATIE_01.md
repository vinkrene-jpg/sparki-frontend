# BOUWOPDRACHT — CLUB- EN TEAMCOMMUNICATIE (CLUB_COMMUNICATIE_01)

**Uitvoerder:** Replit  
**Startcommit:** actuele `main`  
**Type:** breed domeinpakket

## Doel
Maak alle communicatie tussen club, team, trainer, sporter, ouder, ploegleider en mechanieker compleet, veilig en rolgestuurd via in-app, push en e-mail.

## Buiten scope
- Geen openbaar sociaal netwerk.
- Geen marketingcampagnes.
- Geen nieuwe chatprovider wanneer bestaande communicatiebouwstenen bruikbaar zijn.

## Productregels
1. Alleen bevoegde afzenders kunnen doelgroepen bereiken.
2. Minderjarigencommunicatie volgt ouder- en clubbeleid.
3. Gevoelige data wordt niet onnodig in e-mail/push geplaatst.
4. Blokkeren, modereren en melden zijn beschikbaar.
5. Elk bericht heeft auditbare afzender, doelgroep, kanaal en status.
6. Geen merknaam als handelend onderwerp in gewone UI-zinnen.

## Te bouwen
- Individueel bericht, teambericht, clubbericht en rolgerichte berichten.
- Kanalen: in-app, push, e-mail; voorkeuren per gebruiker.
- Bijlagen via bestaande documentenservice.
- Ontvangst-, aflever- en leesstatus waar technisch ondersteund.
- Reacties, threadstructuur, archiveren, zoeken en notificatiebeheer.
- Noodbericht met extra bevestiging en beperkte doelgroep.
- Moderatie, melding, blokkering en auditlog.
- Bewaartermijnen configureerbaar volgens privacybesluiten.
- Minderjarige: wie rechtstreeks mag communiceren; ouderinzage waar besloten.

## Tests
1. Trainer bericht eigen team.
2. Trainer kan ander team niet bereiken.
3. Clubbeheerder verstuurt clubbericht.
4. Mechanieker kan alleen relevante materiaalcommunicatie sturen.
5. Ouder ontvangt jeugdbericht volgens toestemming.
6. Minderjarige ontvangt geen verboden direct bericht.
7. Bijlage respecteert documentrechten.
8. Push/e-mail bevatten geen onnodige gevoelige data.
9. Leesstatus hoort bij juiste ontvanger.
10. Meldingsvoorkeuren worden gerespecteerd.
11. Blokkade voorkomt contact.
12. Moderatieactie wordt gelogd.
13. Directe API-omzeiling faalt.
14. Geen lek tussen clubs/teams.
15. Desktop en mobiel gelijkwaardig.
16. Providerfout toont eerlijke status, geen dubbel verzenden.

## Acceptatiecriteria
Alle rolcombinaties werken volgens rechten; jeugdveiligheid geborgd; geen datalek; kanalen en foutpaden werken; tests groen.

## Bewijs
Start/eind-SHA, gewijzigde bestanden, kanaaltests, e-mail/push-testbewijs, auditlog, screenshots, API-tests en exitcodes.

## Mirror-toets
Mirror test iedere rol, minderjarige flow, bijlagen, meldingsvoorkeuren, blokkeren/modereren, kanaalfouten, API-omzeiling en cross-team-isolatie.
