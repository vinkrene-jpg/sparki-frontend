# BOUWOPDRACHT — TRAININGSPLANNENMARKTPLAATS (PLAN_MARKTPLAATS_01)

**Uitvoerder:** Replit  
**Startcommit:** actuele `main`, SHA vastleggen  
**Type:** breed domeinpakket

## Doel
Maak de volledige keten voor het maken, beoordelen, publiceren, verkopen, kopen en gebruiken van trainingsplannen productiegeschikt, met behoud van auteurschap, versiebeheer, kwaliteitscontrole en veilige aanpassing na aankoop.

## Buiten scope
- Geen algemene webshop.
- Geen losse coachbegeleiding; valt onder trainerpakketten.
- Geen nieuwe betaalprovider.
- Geen medische trainingsclaims.

## Productregels
1. Alleen bevoegde trainers mogen plannen publiceren.
2. Elk plan heeft auteur, versie, doelgroep, duur, vereisten, prijs en wijzigingshistorie.
3. Voor publicatie vindt technische én inhoudelijke kwaliteitscontrole plaats.
4. Oude plannen worden niet automatisch verwijderd, maar kunnen als mogelijk verouderd worden gemarkeerd.
5. Koper behoudt toegang tot een gekocht plan, ook als verkoop stopt, tenzij juridisch onmogelijk.
6. Na aankoop kan het plan samenhangend worden aangepast; belangrijke wijzigingen worden uitgelegd.
7. Oorspronkelijke auteursvermelding blijft behouden.
8. Refund en intrekking hebben duidelijke gevolgen.
9. Geen voorbeeldverkopen of beoordelingen als echte data.

## Te bouwen
### Planbouwer en versiebeheer
- Planmeta, weken, trainingen, doelen, niveau, beschikbare uren, apparatuur.
- Concept, review, gepubliceerd, gepauzeerd, ingetrokken.
- Versies met changelog; bestaande kopers blijven op hun versie of krijgen expliciete migratiekeuze.

### Kwaliteitscontrole
- Doel/doelgroep, logica, belasting, rust, zones, apparatuur, veiligheid, taal en volledigheid.
- Fail-closed bij onvolledige verplichte velden.
- Reviewer en audittrail.

### Marktplaats
- Zoeken, filteren, voorbeeldweergave, prijs, auteur, doelgroep, duur, vereisten, actualiteitsmelding.
- Geen misleidende claims.

### Aankoop en gebruik
- Stripe/bestaande billing hergebruiken.
- Idempotente aankoop.
- Plan activeren in kalender.
- Aanpassen door gebruiker/trainer/AI binnen rechten en veiligheidsregels.
- Belangrijke wijzigingen tonen met reden.

### Beoordelingen en klachten
- Alleen geverifieerde kopers.
- Moderatie en recht op reactie.
- Refund/klachtstatus auditbaar.

## Tests
1. Trainer maakt conceptplan.
2. Onvolledig plan kan niet publiceren.
3. Kwaliteitscontrole registreert bevindingen.
4. Versie-update bewaart historie.
5. Publicatie toont juiste metadata.
6. Aankoop is idempotent.
7. Koper behoudt toegang na verkoopstop.
8. Belangrijke aanpassing wordt uitgelegd.
9. Auteurschap blijft zichtbaar.
10. Verouderd plan toont waarschuwing, blijft beschikbaar.
11. Alleen koper kan beoordelen.
12. Refundstatus verwerkt zonder andere aankopen te raken.
13. Directe API respecteert rechten.
14. Jeugdplan volgt ouder-/toestemmingsregels.
15. Geen mockverkopen of beoordelingen.
16. Desktop en mobiel gelijkwaardig.

## Acceptatiecriteria
Volledige auteur→review→publicatie→aankoop→gebruik→wijziging→beoordeling/refund-flow werkt; rechten en betalingen server-side; bestaande trainingbouwer blijft werken; tests groen.

## Bewijs
Start/eind-SHA, gewijzigde bestanden, migraties, testcommando’s/exitcodes, screenshots, API-bewijs, Stripe-testbewijs en lijst open juridische waarden.

## Mirror-toets
Mirror toetst publicatiecontrole, aankoop, versiebeheer, aanpassing, auteurschap, verouderingsmelding, beoordeling, refund, jeugd, API-omzeiling en data-trust.
