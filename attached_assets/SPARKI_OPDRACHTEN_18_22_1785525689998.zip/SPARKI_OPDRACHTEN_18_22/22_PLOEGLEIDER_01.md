# BOUWOPDRACHT — PLOEGLEIDER EN WEDSTRIJDTEAM (PLOEGLEIDER_01)

**Uitvoerder:** Replit  
**Startcommit:** actuele `main`

## Doel
Maak de volledige ploegleiderflow productiegeschikt, van selectie en voorbereiding tot live begeleiding, uitvallers, uitslag en wedstrijdverslag.

## Buiten scope
- Geen nieuwe route-engine.
- Geen algemene clubadministratie.
- Geen materiaalvoorraad buiten koppeling met `TEAM_MECHANIEKER_01`.
- Categoriemapping alleen gebruiken wanneer brongevalideerd; anders fail-closed.

## Productregels
1. Ploegleider is een zelfstandige rol met server-side rechten.
2. Alleen toegewezen team/wedstrijd zichtbaar.
3. Live locatie vereist expliciete toestemming en pakketrecht.
4. Technische gids/course points volgen bestaande Compleet-poorten.
5. Veiligheidsinformatie wordt nooit commercieel verborgen.
6. Minderjarigen volgen ouder- en clubtoestemming.

## Te bouwen
- Wedstrijdselectie, reserverenners, startlijst en rollen.
- Technische gids upload/controle, parcours, course points, bevoorrading, gevaren.
- Warming-up, materiaalkeuze en teaminstructies.
- Volgauto-instellingen en live kaart met toestemming.
- Statussen: gestart, uitgevallen, gefinisht, DNS/DNF/DSQ waar ondersteund.
- Communicatiesignalen naar renners/team.
- Uitslag, notities, wedstrijdverslag en PDF-export.
- Koppeling met trainer, mechanieker, ouder en clubrechten.

## Tests
1. Ploegleider ziet alleen toegewezen team.
2. Selectie en startlijst werken.
3. Onbekende categorie blokkeert risicovolle automatisering.
4. Technische gids lekt geen course points zonder recht.
5. Veiligheidsinformatie blijft zichtbaar.
6. Live locatie zonder toestemming is leeg.
7. Live locatie met toestemming werkt voor bevoegd account.
8. Minderjarige volgt oudertoestemming.
9. Uitvaller registreren werkt en is auditbaar.
10. Uitslag/verslag/PDF gebruiken echte data.
11. Mechanieker ziet alleen materiaalrelevante info.
12. Directe API-omzeiling faalt.
13. Desktop en mobiel gelijkwaardig.
14. Geen mockstartlijst of uitslag.
15. Providerfout toont eerlijke status.

## Acceptatiecriteria
Ploegleider kan wedstrijd voorbereiden, live begeleiden en afronden; rechten, privacy en course-pointpoorten kloppen; tests groen.

## Bewijs
Start/eind-SHA, gewijzigde bestanden, rolmatrix, API-tests, live-locatietests, PDF-bewijs, screenshots, exitcodes en bekende beperkingen.

## Mirror-toets
Mirror toetst roltoegang, selectie, gids/course points, veiligheid, live toestemming, jeugd, uitvaller, uitslag/verslag/PDF, mechaniekerkoppeling en API-omzeiling.
