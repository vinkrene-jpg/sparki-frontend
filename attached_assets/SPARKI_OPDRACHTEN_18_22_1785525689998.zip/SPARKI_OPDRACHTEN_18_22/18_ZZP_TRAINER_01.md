# BOUWOPDRACHT — ZZP-TRAINER EN TRAINERBEDRIJF (ZZP_TRAINER_01)

**Uitvoerder:** Replit  
**Vrijgave:** René  
**Type:** breed domeinpakket  
**Startcommit:** actuele `main`, SHA opnemen in eindrapport  
**Grondslag:** bestaande trainer-/coacharchitectuur, abonnementen, betalingen, rollen, data-trust en communicatie

## Doel
Maak de volledige commerciële flow voor een zelfstandige trainer of trainerbedrijf productiegeschikt: profiel aanmaken, diensten aanbieden, klanten werven, begeleiding starten, afspraken en betalingen beheren, klachten en beëindiging afhandelen, zonder dat sporterdata tussen trainers lekt.

## Buiten scope
- Geen nieuwe algemene marktplaatsarchitectuur buiten de bestaande services.
- Geen automatische belastingaangifte of boekhouding.
- Geen nieuwe betaalprovider naast Stripe.
- Geen trainingsplanmarktplaats; die valt onder `PLAN_MARKTPLAATS_01`.
- Geen volledige clubadministratie.

## Productregels
1. Een trainer kan een openbaar professioneel profiel beheren met specialisaties, doelgroep, talen, beschikbaarheid, tarieven en locatie/online.
2. Een sporter kan een trainer vinden, vergelijken, benaderen en koppelen.
3. Een trainer ziet uitsluitend gekoppelde klanten en alleen gegevens waarvoor toestemming bestaat.
4. Commerciële afspraken zijn vastgelegd als traject, abonnement of losse dienst.
5. Betaling, refund, annulering en beëindiging zijn server-side en auditplichtig.
6. Trainer en sporter behouden ieder hun eigen account en data-eigenaarschap.
7. Een trainer kan stoppen; klanten en historie verdwijnen niet stilzwijgend.
8. Beoordelingen zijn alleen mogelijk na een aantoonbare dienstrelatie.
9. Minderjarigen kunnen alleen via de bestaande ouder-/toestemmingsflow worden begeleid.
10. Geen mock-, demo- of voorbeeldomzet als echte bedrijfsdata.

## Te bouwen
### Profiel en verificatie
- Trainerprofiel met foto/logo, bio, specialisaties, doelgroepen, ervaring, kwalificaties, talen, regio en online/offline.
- Bedrijfsgegevens, KvK-/btw-velden configureerbaar; geen automatische juridische validatie verzinnen.
- Statussen: concept, in review, actief, gepauzeerd, gestopt.
- Alleen geverifieerde trainers zichtbaar in zoekresultaten.

### Aanbod en tarieven
- Diensten: kennismaking, losse sessie, maandbegeleiding, traject.
- Prijs, looptijd, inbegrepen onderdelen, annuleringsvoorwaarden.
- Beschikbaarheid en maximum aantal klanten.

### Klantflow
- Sporter zoekt/filtert en bekijkt profiel.
- Contactverzoek, acceptatie/weigering, intake, start begeleiding.
- Toestemmingen per gegevenstype.
- Pauzeren, beëindigen, overstappen naar andere trainer.

### Betaling en uitbetaling
- Hergebruik Stripe Connect of bestaande betaalarchitectuur; geen parallel systeem.
- Betaling, commissie configureerbaar, uitbetaling, refund, chargeback.
- Geen volledige kaartgegevens opslaan.
- Factuur-/bewijsdocumenten via bestaande documentenservice.

### Dashboard en communicatie
- Trainerdashboard: klanten, trajectstatus, omzetstatus, open acties, afspraken.
- Sporterdashboard: trainer, afspraken, kosten, trajectstatus.
- In-app/e-mailmeldingen via bestaande communicatiebouwstenen.

### Stoppen en overdracht
- Trainer kan profiel pauzeren of stoppen.
- Lopende klanten krijgen duidelijke communicatie.
- Historische data blijft bij sporter; geen automatische overdracht zonder toestemming.

## Migratie en veiligheid
- Hergebruik bestaande users, roles, trainer links, billing en auditlog.
- Nieuwe tabellen alleen als huidige structuren onvoldoende zijn.
- Migraties op lege database en kopie met bestaande trainerkoppelingen testen.
- Geen echte klantdata verwijderen.

## Tests
1. Trainerprofiel aanmaken en activeren.
2. Ongeverifieerd profiel niet publiek zichtbaar.
3. Sporter vindt en vergelijkt trainers.
4. Koppeling vereist acceptatie en toestemming.
5. Trainer ziet alleen gekoppelde sporters.
6. Minderjarige koppeling vereist oudertoestemming.
7. Dubbele koppeling wordt voorkomen.
8. Betaling is idempotent.
9. Refund past status correct aan zonder sportdata te verwijderen.
10. Chargeback veroorzaakt geen dataverlies.
11. Beoordeling alleen na echte dienstrelatie.
12. Trainer pauzeert en wordt niet meer gevonden.
13. Trainer stopt; klanten behouden historie.
14. Directe API-aanroepen respecteren dezelfde rechten als UI.
15. Desktop en mobiel tonen dezelfde status.
16. Geen mockdata als echte omzet of klanten.

## Acceptatiecriteria
- Volledige flow van profiel tot betaling en beëindiging werkt.
- Geen datalek tussen trainers of klanten.
- Alle betaal- en rolbeslissingen server-side.
- Bestaande trainer/coachfunctionaliteit blijft werken.
- Alle tests groen en typecheck exit 0.

## Bewijs
Per regel: commando, resultaat, exitcode. Lever start-SHA, eind-SHA, gewijzigde bestanden, migratiebewijs, API-contracten, desktop- en mobiel bewijs, betaaltestbewijs en bekende restpunten.

## Stopcondities
Stop alleen bij ontbrekende betrouwbare betaal-/uitbetalingsbasis, risico op dataverlies, of noodzakelijke architectuurherschrijving. Een ontbrekende juridische bedrijfsveldwaarde is geen stopconditie; maak die configureerbaar.

## Mirror-toets
Mirror toetst trainerprofiel, zoeken, koppelen, toestemming, betaling, refund, beëindiging, minderjarige flow, directe API-omzeiling, data-isolatie en desktop/mobiel. Eén eindoordeel: GOEDGEKEURD, AFGEKEURD of NIET BEWIJSBAAR.
