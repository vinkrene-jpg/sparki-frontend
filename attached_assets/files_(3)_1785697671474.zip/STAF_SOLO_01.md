# Solo-bruikbare stafomgevingen

**Onderdeel:** stafrollen — mechanieker, soigneur, voedingsdeskundige, medische staf
**Nagekeken tegen:** main `3313b681`, 2 augustus 2026
**Besluit:** René, 2 augustus 2026
**Volgorde:** ná `GRATIS_A_TOT_Z_01`. De instructie kan nu klaarliggen.

---

## Doel

Elke stafrol krijgt een kern die werkt **zonder dat er een club of ploeg in Sparki zit**. Iemand kan het alleen gebruiken, ontdekt dat het werkt, en overtuigt daarmee zijn ploeg.

Het groeimodel erachter: geef één gebruiker iets dat op zichzelf al waarde heeft, dan trekt hij de organisatie mee naar binnen.

---

## Wat er al ligt

Er is een mechaniekerpagina (`pages/mechanieker.tsx`, route `/mechanieker`), en in het schema staan `equipment`, `equipment_assets`, `garage_bikes`, `bike_scans`, `material_analyses` en `club_race_material_items`. Dit wordt dus niet vanaf nul gebouwd.

---

## Per rol

### Mechanieker — het sterkste geval

Eigen magazijn: wat heb ik op voorraad, welk gereedschap, welke fietsen, wat is er onderweg kapot gegaan, wat moet er mee naar zaterdag. Onderhoud per fiets met een historie.

**Telefoon-eerst.** Dit is werk dat je staand in een werkplaats doet, niet zittend achter een bureau. Grote knoppen, bruikbaar met vieze handen.

### Soigneur

Eigen voorraad en een verzorgingsschema. Wat is er op, wat moet mee, wie heeft wanneer wat gehad.

### Voedingsdeskundige

Eigen klanten en eigen plannen — feitelijk hetzelfde model als de zelfstandige trainer, met de bestaande grens: de trainer ziet de uitvoering, niet de analyse eronder, en er is geen samengevoegd dossier.

### Medische staf — begint later

`STAF-01` — **Geen solo-omgeving met gezondheidsgegevens.** Voor deze rol begint het pas zodra er een gekoppelde sporter is die toestemming heeft gegeven. Gezondheidsgegevens vastleggen zonder koppeling en zonder toestemming is elders in Sparki uitdrukkelijk dichtgezet, en dat blijft zo — ook als het de instapdrempel verhoogt.

---

## De grens met team

`STAF-02` — **"Voor welk team werk ik" en de ploegsamenstelling zijn niet solo.** Daar is een team voor nodig. Toon die onderdelen niet uitgegrijsd maar gewoon niet, met één regel die uitlegt wat er bij komt zodra hij aan een ploeg gekoppeld wordt.

`STAF-03` — Zodra er wél een ploeg is, klikt de solo-omgeving erin: zijn magazijn wordt de bron voor de materiaallijst van de wedstrijddag. Geen tweede administratie ernaast.

---

## Waarom dit veilig kan

`STAF-04` — De solo-omgevingen bevatten **geen gegevens van andere personen**. Een magazijn, gereedschap en fietsen zijn spullen, geen mensen. Daarom kan dit zonder club, zonder rechtenketen en zonder toestemming — en daarom kan het bij de medische staf juist niet.

---

## Wat er niet bij hoort

Solo-toegang tot ploegfunctionaliteit · een medische solo-omgeving · een volledige teamomgeving in deze fase · een tweede materiaaladministratie naast de bestaande tabellen.

---

## Acceptatie

- een mechanieker zonder club of ploeg kan zijn magazijn, gereedschap, fietsen en onderhoud beheren, op zijn telefoon
- een soigneur zonder ploeg kan zijn voorraad en verzorgingsschema bijhouden
- een voedingsdeskundige zonder ploeg kan zijn klanten en plannen beheren
- medische staf heeft zonder gekoppelde sporter met toestemming geen enkele gezondheidsfunctie
- ploegonderdelen zijn niet zichtbaar in solo-modus, met één regel uitleg in plaats van uitgegrijsde knoppen
- koppelt de mechanieker later aan een ploeg, dan is zijn magazijn de bron voor de materiaallijst — zonder overtypen
- de bestaande tabellen zijn gebruikt en uitgebreid, niet omzeild

Lever de bewijsbundel per rol op een vaste SHA.
