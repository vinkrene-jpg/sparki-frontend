# Openbare kennisbank

**Onderdeel:** kennis en vindbaarheid
**Nagekeken tegen:** main `3313b681`, 2 augustus 2026
**Gerelateerd:** `KENNIS_01` — die regels blijven onverkort gelden

---

## Doel

Een selectie kennisartikelen openbaar, zonder inloggen, zodat Sparki gevonden wordt. Dit is het goedkoopste kanaal dat er is: er staan ruim tweehonderdnegentig items klaar die nu niemand kan zien.

---

## Correctie — de selectiegrond is hier ingevuld, niet opengelaten

De oorspronkelijke specificatie zegt dat de selectiecriteria "vastgelegd" moeten worden, zonder te zeggen welke. Dat is een open eind waar in de bouw iets van gemaakt wordt. Hierbij ingevuld:

`KEN-01` — **Openbaar is: algemene uitleg.** Wat een intervaltraining is, hoe herstel werkt, waar je op let bij bandenkeuze, wat koolhydraten doen tijdens een lange rit. Kennis die op zichzelf staat en voor iedereen geldt.

`KEN-02` — **Niet openbaar is: alles wat aan een persoon of een plan hangt.** Uitleg die alleen betekenis heeft naast je eigen gegevens, je schema of je waarden. Dat is waarvoor Compleet wordt betaald en dat moet een reden blijven.

`KEN-03` — **Jeugdgemarkeerde inhoud wordt niet openbaar.** Niet omdat het geheim is, maar omdat inhoud gericht op minderjarigen niet vindbaar hoort te zijn buiten de context van een club en een ouder. Dat sluit aan op de rest van de jeugdregels.

`KEN-04` — **Geen jeugdvoedingsinhoud**, openbaar noch besloten. Bestaand besluit.

`KEN-05` — De selectie is een **expliciete markering per artikel**, geen automatische regel op een categorie. Iemand zet hem aan; het staat vast wie en wanneer.

---

## Weergave van een openbaar artikel

`KEN-06` — Elk openbaar artikel toont: titel · beschrijving · **de bron** · **de datum van bijwerken** · een eigen vast adres.

`KEN-07` — Bron en datum zijn niet optioneel en staan zichtbaar bij het artikel, niet onderaan in kleine letters. Dat is wat het onderscheidt van een blog.

`KEN-08` — Technisch vindbaar: eigen adres per artikel, eigen titel en beschrijving voor zoekmachines, leesbaar zonder JavaScript.

---

## Het pad naar het product

`KEN-09` — Onderaan een artikel één rustige verwijzing naar Sparki. Geen banner, geen pop-up, geen knop halverwege de tekst.

`KEN-10` — **Het artikel blijft een artikel.** Wie erop landt moet zijn antwoord vinden, ook als hij nooit klant wordt. Een kennisbank die verkoopt in plaats van uitlegt, wordt niet gedeeld en niet teruggevonden.

---

## Wat er niet bij hoort

Alles openbaar maken · openbare toegang tot inhoud die aan een persoonlijk plan hangt · het artikel ombouwen tot verkooppagina · afwijken van de regels uit `KENNIS_01`.

---

## Acceptatie

- er is een expliciete markering per artikel, met vastgelegd wie hem zette en wanneer
- een openbaar artikel is bereikbaar zonder inloggen en heeft een eigen adres
- bron en datum van bijwerken staan zichtbaar bij elk openbaar artikel
- geen enkel jeugdgemarkeerd artikel is openbaar
- er komt nergens jeugdvoedingsinhoud voor
- niet-geselecteerde items blijven achter inloggen en waar van toepassing achter Compleet
- de artikelen zijn indexeerbaar en leesbaar zonder JavaScript
- er staat één rustige verwijzing naar het product, onderaan

Lever de bewijsbundel op een vaste SHA, met de lijst van openbaar gemarkeerde artikelen en de grond per artikel.
