# SPARKI_BUILD_01 — F11 Centrale bestands- en medialaag

**Fase:** F11 — de laatste openstaande fase van `SPARKI_BUILD_01`
**Nagekeken tegen:** main `3313b681`, 2 augustus 2026

---

## Hoofdcorrectie — het meeste staat er al

De oorspronkelijke specificatie beschrijft F11 als het compleet maken van een fundament. **Gemeten: de `files`-tabel in `lib/db/src/schema/files.ts` heeft al vrijwel alles.**

| Veld | Dekt welke eis |
|---|---|
| `contentType` | gesnift op de **echte inhoud** (magic bytes), niet op de geclaimde extensie |
| `sha256` | checksum — de basis voor duplicaatherkenning |
| `version` | doorlopende versie per eigenaar en objectpad |
| `revokedAt` + `revokedByClerkId` | intrekken: 410 of 404 op elk serveerpad, ook via een oude link |
| `retentionCategory` | stuurt de opruimtermijn |
| `sizeBytes`, `objectPath`, `originalName` | grootte, opslag, weergavenaam |

**Gevolg: F11 is grotendeels verhuizen, niet bouwen.** Reken daar de tijd op.

---

## Wat er echt nog moet gebeuren

`F11-01` — **De losse uploadpaden omzetten.** Gemeten zijn er nog twee die naast de centrale laag staan: `photo_lab_uploads` (`schema/photo-lab.ts`) en `virtual_media` (`schema/sparki-world.ts`). `message_attachments` gebruikt de centrale laag al. Dit is het grootste deel van het werk.

`F11-02` — **Vervangen zonder historieverlies.** Het `version`-veld bestaat, maar de handeling "vervang dit bestand en bewaar de vorige versie" moet er nog zijn. Een oude versie blijft opvraagbaar voor wie er recht op had.

`F11-03` — **Duplicaatherkenning daadwerkelijk gebruiken.** De checksum wordt vastgelegd; controleer of hij bij uploaden ook wordt gebruikt om een dubbel bestand te herkennen, en bouw dat als het ontbreekt.

`F11-04` — **Veilige bestandsnamen.** Geen padverwijzingen, geen gevaarlijke tekens, geen namen die op het bestandssysteem iets anders betekenen.

`F11-05` — **Voorbeeldweergave en downloaden** als één pad, met rechtencontrole vóór het streamen — zoals `objectPath` het al beschrijft.

`F11-06` — **Schermlezertekst** waar een afbeelding betekenis draagt.

---

## Wat er niet bij hoort

Een uploadoplossing per module · oude paden naast de nieuwe laten bestaan · mediabewerking zoals bijsnijden of filters · een tweede opslagvoorziening.

---

## Acceptatie

- `photo_lab_uploads` en `virtual_media` gebruiken de centrale laag; hun eigen paden bestaan niet meer
- een bestand vervangen bewaart de vorige versie en die blijft opvraagbaar voor wie er recht op had
- een dubbel bestand wordt bij uploaden herkend op checksum
- een ingetrokken bestand geeft 410 of 404 op elk pad, ook via een link die eerder werkte
- een onbevoegde krijgt het bestand niet, ook niet via een directe aanroep met het bestands-id
- een bestand dat zich voordoet als een toegestaan type wordt geweigerd op inhoud
- bestandsnamen zijn veilig
- afbeeldingen met betekenis hebben schermlezertekst

Lever de bewijsbundel op een vaste SHA, met per omgezet pad het bewijs dat het oude pad weg is.
