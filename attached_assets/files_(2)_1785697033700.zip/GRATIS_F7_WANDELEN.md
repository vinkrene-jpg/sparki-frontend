# GRATIS_A_TOT_Z_01 — F7 Wandelen

**Fase:** F7 — ketenstap O
**Nagekeken tegen:** main `3313b681`, 2 augustus 2026
**UX:** `SPARKI_TELEFOON_UX_01` v1.1 op elk scherm

---

## Correctie — de analyse na een wandeling is een andere dan na een rit

De oorspronkelijke specificatie neemt "afstand, gemiddelde en maximale snelheid" over uit het fietsverhaal. **Maximale snelheid zegt bij wandelen niets.**

Wat op 1 augustus is vastgelegd voor wandelingen terugzien: **afstand · tijd · gemiddelde snelheid · hoogtemeters en het hoogteprofiel · tempo per kilometer · hartslag** — en vergelijken over tijd. Dat is bewust rijker dan de basis bij fietsen; het was een uitzondering op de afbakening.

Bron van de gegevens: zowel wat in Sparki genavigeerd is als wat via Strava en Garmin binnenkomt.

---

## Wat er al is

`app/(app)/navigate/[id].tsx` en `lib/ride-flow.ts` kennen wandelen al, en `engines/data-hub/sports.ts` onderscheidt de sporten. De keten bestaat dus; de opdracht is hem sluitend maken voor wandelen.

---

## De keten

Wandelroute plannen of kiezen · navigatie starten over dezelfde kaart · onderweg afslag-voor-afslag met spraak · afronden · de analyse hierboven.

**Onderweg toont wandelen:** afstand gelopen, te gaan, totaal en snelheid. Niet de fietsgegevens.

---

## De gedeelde limiet

Fietsen en wandelen delen **één potje** van acht gebruikte routes per maand. Dat is besloten op 31 juli.

**Gemeten: dit werkt al** — de telfunctie in `lib/route-limits.ts` filtert niet op sporttype. Verifieer het op fixture A en bouw er niets bij. Een aparte limiet voor wandelen is uitdrukkelijk verboden.

---

## Pakket

Wandelen hoort bij **Gratis en Go**. Geen wandelspecifieke trainings- of coachfuncties — die vallen buiten beide.

---

## Acceptatie

De hele keten werkt met wandelgegevens · de analyse toont afstand, tijd, gemiddelde snelheid, hoogtemeters, profiel, tempo per kilometer en hartslag · wandelen en fietsen tellen aantoonbaar in hetzelfde potje, geverifieerd op fixture A · onderweg staan wandelgegevens en geen fietsgegevens · geen scrollen voor de hoofdhandeling · geen doodlopend scherm · app en browser identiek.

Lever de bewijsbundel op een vaste SHA.
