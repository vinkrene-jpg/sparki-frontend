# GRATIS_A_TOT_Z_01 — F6 Navigatie en rit

**Fase:** F6 — ketenstappen L, M en N
**Nagekeken tegen:** main `3313b681`, 2 augustus 2026
**UX:** `SPARKI_TELEFOON_UX_01` v1.1 op elk scherm

---

## Wat er al is — niet opnieuw bouwen

- **Web:** `components/sparki/route-navigator.tsx` — de navigatielaag
- **App:** `app/(app)/navigate/[id].tsx` — navigeren op de telefoon
- **Ritweergave:** `app/(app)/ride/[id].tsx` toont na afloop onder meer de gemiddelde snelheid, met vermelding van de bron per waarde
- `components/sparki/workout-hud.tsx` — de weergave onderweg

De opdracht is dus afmaken en gelijktrekken, niet opnieuw bouwen.

---

## L — Navigatie starten

Vanuit de route start je de navigatie, en die legt zich **over dezelfde kaart**. Geen apart navigatiescherm: de planningsbediening verdwijnt, de navigatiebediening komt ervoor in de plaats. Starten is de hoofdhandeling en staat in beeld zonder te scrollen.

## M — Onderweg

Afslag-voor-afslag met spraakaanwijzingen. Wat er aan gegevens te zien is hangt af van wie je bent: wandelen toont afstand gelopen, te gaan, totaal en snelheid · een gewone fietser daarbij de accu · wielrenner, mtb en gravel daarbij wat er via ANT+ en Bluetooth binnenkomt.

Leesbaar in zonlicht, bedienbaar in beweging, geen onderbrekingen tijdens het rijden.

## N — Rit afronden

Na afloop een basisanalyse met **afstand, gemiddelde snelheid en maximale snelheid**. Gemeten: de gemiddelde snelheid staat er; controleer of afstand en maximale snelheid er ook zijn en vul aan wat ontbreekt.

De analyse is direct bereikbaar, zonder extra stappen.

---

## Wat er niet bij hoort

Vermogen, hartslagzones en trainingsanalyse (Compleet) · herplannen of coachadvies tijdens de rit · offline kaarten · een tweede kaartmotor voor navigatie.

---

## Acceptatie

De navigatie start over dezelfde kaart · afslag-voor-afslag en spraak werken · de rit is af te ronden · de basisanalyse toont de drie waarden · geen scrollen voor starten of afronden · geen doodlopend scherm in L → M → N · app en browser gedragen zich identiek.

Lever de bewijsbundel op een vaste SHA, met de schermen van telefoon én browser.
