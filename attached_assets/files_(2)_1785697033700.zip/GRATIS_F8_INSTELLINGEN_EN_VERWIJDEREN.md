# GRATIS_A_TOT_Z_01 — F8 Instellingen en account verwijderen

**Fase:** F8 — ketenstappen Q en R
**Nagekeken tegen:** main `3313b681`, 2 augustus 2026
**UX:** `SPARKI_TELEFOON_UX_01` v1.1 op elk scherm

---

## Herstelpunt — de bewaartermijn klopt niet

**Gemeten in `artifacts/api-server/src/lib/account-privacy.ts` regel 26:**

```
export const DELETE_RECOVERY_DAYS = 14;
```

**Besloten op 1 augustus 2026: dertig dagen.** Iemand die zich op dag twintig bedenkt, is nu zijn account kwijt.

`GF8-01` — Zet dit op **30**, en maak het configureerbaar in plaats van een vaste waarde in de code. Dit is de eerste taak van deze fase.

---

## Correctie — "beweging uitzetten" gaat over animaties

De oorspronkelijke specificatie leest dit als "beweging/activiteitsregistratie uitzetten". Dat is een andere functie.

**Bedoeld is de voorkeur voor minder beweging**: de animaties, de zwevende kaarten en de dieptelaag. Die instelling bestaat al — `hooks/use-motion-preference` en `MotionPreferenceSync` in `App.tsx`.

`GF8-02` — Zorg dat die instelling in de instellingen te vinden is en dat alles volledig bruikbaar blijft met beweging uit. Geen armere variant voor wie het aanzet.

---

## Q — Instellingen

Profiel bekijken en aanpassen · minder beweging aan of uit · taal · uitloggen.

`GF8-03` — Uitloggen moet een gewone uitlogknop zijn voor dit apparaat. **Gemeten probleem:** de enige gevonden uitlogmogelijkheid is "Overal uitloggen", die alle sessies op alle apparaten beëindigt. Dat is een noodknop, geen dagelijkse handeling.

---

## R — Account verwijderen

**Wat er al is:** `lib/account-privacy.ts` levert een volledige uitdraai van alle gegevens (`exportAccountData`) en kent een bevestigingszin. Toegangssleutels van gekoppelde diensten gaan bewust niet mee — dat is juist.

Wat er moet gelden:

`GF8-04` — Een uitdraai van alle gegevens, beschikbaar vóór of tijdens het verwijderen.

`GF8-05` — **Dertig dagen** bewaartermijn, met de keuze om **direct definitief** te verwijderen.

`GF8-06` — Bericht op het moment van verwijderen. **Geen aparte herinnering** halverwege de termijn — dat is een besluit, geen omissie.

`GF8-07` — Binnen de termijn is het omkeerbaar, tenzij direct definitief is gekozen. Daarna is inloggen niet meer mogelijk.

`GF8-08` — **Voor een club geldt altijd dertig dagen en bestaat "direct definitief" niet.** Valt buiten deze fase, maar bouw de termijn zo dat dat onderscheid mogelijk is.

---

## Wat er niet bij hoort

Uitgebreide privacyinstellingen of marketingvoorkeuren · beheerdersfuncties · verwijderen dat alleen via support kan · verschil tussen app en browser.

---

## Acceptatie

Profiel is bereikbaar en aan te passen · minder beweging werkt en niets wordt onbruikbaar · taal wisselt en wordt toegepast · uitloggen werkt voor dit apparaat zonder andere apparaten te raken · verwijderen biedt uitdraai, dertig dagen en direct definitief · de termijn staat als configuratiewaarde op 30 · geen scrollen voor de hoofdhandeling · geen doodlopend scherm · app en browser identiek · na definitief verwijderen is inloggen onmogelijk.

Lever de bewijsbundel op een vaste SHA.
