# SPARKI — DAGKAART 31-07-2026

## Afgerond

- Pakketgrens voor routes vastgesteld: plannen, bekijken, GPX-export, navigatie, spraak en hoogteprofiel blijven Gratis.
- Go krijgt uitgebreid routebibliotheekbeheer; Gratis behoudt basisinzage, openen en verwijderen van eigen routes.
- Compleet krijgt course points/wedstrijdinformatie en live vrienden/ploeg op de kaart.
- Gratis gebruiksmodel vastgesteld: 8 daadwerkelijk gebruikte routes per maand; plannen telt niet.
- Gratis opslagmodel vastgesteld: maximaal 3 routes, 30 dagen bewaren.
- Bouwreeks `ROUTE_PAKKET_01` tot en met `02d` opgesplitst, gereviewd en aan Replit doorgegeven.
- PR 507 CI onafhankelijk gecontroleerd: validators, typecheck en admin-smoke groen op commit `b9fc3c8676f4…`, run `30649048529`.
- Dummy CI-waarden bevestigd als uitsluitend tijdelijke placeholders; geen productiedeploy mogelijk.

## Nu bezig

- Replit: `ROUTE_PAKKET_01 — Sleutels en poorten`.
- Eerst veiligheidscontrole op concrete endpoints en behoud van de gratis basisbibliotheek.

## Volgende stap

1. Replit levert bewijs voor `ROUTE_PAKKET_01`.
2. Mirror test Gratis, Go en Compleet op desktop en mobiel.
3. René geeft pas daarna vrij voor `ROUTE_PAKKET_02a`.

## Open beslissingen

- Downgrade naar Gratis bij meer dan drie routes: voorstel is drie laten kiezen en overige routes herstelbaar laten vervallen.
- Bewaartermijn van gebruiks- en fair-usegegevens.
- Fair-usedrempel pas bepalen na echte meetgegevens.
- Definitie van “basis Gratis, volledig Go” voor route-opmerkingen en route onderweg inkorten.

## Blokkades

- Geen inhoudelijke blokkade voor `ROUTE_PAKKET_01`.
- De automatische uurlijkse repo-verificatie is onbetrouwbaar door sandbox-schijfruimte en ontbrekende connector; dit is infrastructuur, geen bewezen repo-fout.
