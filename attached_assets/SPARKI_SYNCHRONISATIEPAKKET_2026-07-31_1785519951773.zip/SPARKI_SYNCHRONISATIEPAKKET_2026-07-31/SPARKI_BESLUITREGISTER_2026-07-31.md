# SPARKI — BESLUITREGISTER 31-07-2026

## SPARKI-BESLUIT-2026-002 — Routerechten per pakket

**Status:** besloten

### Gratis

- Route plannen en genereren.
- Route aanpassen op afstand, tijd, wegtype, hoogte en wind.
- Route bekijken.
- GPX exporteren.
- Afslag-voor-afslag navigatie.
- Spraakaanwijzingen.
- Hoogteprofiel met schuifbalk.
- Basisbibliotheek: eigen routes zien, openen en verwijderen.

### Go

- Uitgebreid routebibliotheekbeheer, waaronder zoeken en sorteren.
- Geen persoonlijk trainingsplan.
- Geen AI-trainer.

### Compleet

- Alles van Go.
- Course points en wedstrijdinformatie in routes.
- Live vrienden en ploeg op de kaart, altijd onder bestaande toestemming en privacyregels.

### Motivatie

Gratis routes zijn de acquisitiewig tegenover Komoot. De gebruiker moet de kwaliteit werkelijk kunnen ervaren. Go verkoopt extra gemak en beheer. Compleet ondersteunt de wedstrijdsporter integraal.

---

## SPARKI-BESLUIT-2026-003 — Gratis routegebruik en opslag

**Status:** besloten, gefaseerd te bouwen

- Plannen, verschuiven, herberekenen en bekijken tellen niet.
- Een route telt bij definitief opslaan, succesvolle GPX-export of minimaal 20% rijden in Sparki.
- Dezelfde route telt maximaal eenmaal per kalendermaand.
- Gratis krijgt 8 gebruikte routes per kalendermaand.
- Gratis kan maximaal 3 routes tegelijk bewaren.
- Gratis opgeslagen routes hebben een bewaartermijn van 30 dagen.
- Fair use wordt eerst gemeten; er is nog geen gebruikersblokkade of definitieve drempel.
- Kalendergrenzen volgen `Europe/Amsterdam`.

---

## SPARKI-BESLUIT-2026-004 — Bouw- en vrijgaveproces

**Status:** besloten

- Eén kleine opdracht tegelijk.
- Replit bouwt uitsluitend de goedgekeurde scope.
- Mirror bewijst iedere opdracht onafhankelijk.
- De volgende opdracht start uitsluitend na expliciete vrijgave door René.
- Een Agent mag niet zelfstandig doorbouwen na een groene eigen test.
- Gebouwd zonder Mirror-bewijs heet `BUILT_UNPROVEN`, niet gereed.

---

## SPARKI-BESLUIT-2026-005 — PR 507 CI-bewijs

**Status:** bewezen groen, niet gemerged

- Correcte commit: `b9fc3c8676f44473b99a3da9b9bbda2e76f5f887`.
- GitHub Actions run: `30649048529`.
- Validators: groen.
- Typecheck: groen.
- Admin-smoke: groen.
- Drie bestaande GitHub-platformwaarschuwingen over Node.js 20 zijn niet nieuw.
- Dummy CI-variabelen zijn uitsluitend placeholders in de pull-requestworkflow.
- PR 507 blijft ongemerged totdat René anders beslist.
