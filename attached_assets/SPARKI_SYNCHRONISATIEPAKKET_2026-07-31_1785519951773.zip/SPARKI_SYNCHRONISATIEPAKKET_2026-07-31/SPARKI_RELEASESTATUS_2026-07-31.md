# SPARKI — RELEASESTATUS 31-07-2026

## Bewezen

### PR 507 CI-governance
- Commit `b9fc3c8676f44473b99a3da9b9bbda2e76f5f887`.
- Run `30649048529`.
- Validators, typecheck en admin-smoke groen.
- Geen nieuwe CI-regressie aangetoond.
- PR nog niet gemerged.

## Besloten maar nog niet volledig gebouwd of bewezen

- Gratis routeplanner als acquisitiewig.
- Pakketverdeling Gratis/Go/Compleet voor routes.
- 8 gebruikte routes per maand voor Gratis.
- 3 opgeslagen routes, 30 dagen bewaartermijn.
- Gefaseerde bouwreeks 01 tot en met 02d.

## In uitvoering

### `ROUTE_PAKKET_01`
- Door René vrijgegeven.
- Replit mag uitsluitend 01 bouwen.
- Mirror-goedkeuring nog vereist.

## Wacht op eerdere poort

- `ROUTE_PAKKET_02a` — wacht op Mirror 01.
- `ROUTE_PAKKET_02b` — wacht op Mirror 02a.
- `ROUTE_PAKKET_02c` — wacht op Mirror 02b en downgradebesluit.
- `ROUTE_PAKKET_02d` — wacht op Mirror 02c en bewaartermijnbesluit.

## Infrastructuurproblemen buiten de repo

De uurlijkse automatische repo-verificatie kon meerdere keren niet uitvoeren door:
- sandboxmelding `No space left on device`;
- ontbrekende GitHub-connector in die taak;
- geblokkeerde webfallback.

Dit bewijst geen fout in Sparki. Gebruik deze taak niet als actuele repo-status totdat de omgeving is hersteld.

## Releaseblokkades die blijven gelden

- Geen betaalde commerciële release zonder betrouwbare pakketpoorten en abonnementstests.
- Geen releaseclaim zonder Mirror-bewijs.
- Geen persoonlijke mock- of fallbackdata.
- Routes en navigatie moeten op echte apparaten betrouwbaar zijn.
- Juridische, privacy-, toegankelijkheids- en continuïteitsgates blijven van kracht.
