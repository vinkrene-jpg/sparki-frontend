# SPARKI — ROADMAP ROUTEPAKKET

## Actieve keten

### 1. Sleutels en poorten (`ROUTE_PAKKET_01`)

**Status:** door René vrijgegeven; in uitvoering of wacht op Replit-oplevering.

Resultaat:
- Go-sleutel voor uitgebreid routebibliotheekbeheer.
- Compleet-sleutels voor course points en live vrienden/ploeg.
- Server-side afdwinging.
- Zeven gratis routefuncties beschermd door regressietests.
- Correcte Go/Compleet-weigeringstekst.
- Gratis, Go en Compleet als echte niet-legacy testidentiteiten.

**Poort:** Mirror-goedkeuring vereist.

### 2. Telling van routegebruik (`ROUTE_PAKKET_02a`)

**Status:** wacht op Mirror-goedkeuring van 01.

Resultaat:
- Meten voor alle pakketten.
- Opslaan, exporteren en eventueel 20% rijden registreren.
- Idempotentie en maandgrens Europe/Amsterdam.
- Nog niets blokkeren.

### 3. Limiet en reserveringen (`ROUTE_PAKKET_02b`)

**Status:** wacht op 02a + Mirror.

Resultaat:
- Gratis maximaal 8 gebruikte routes per maand.
- Nieuwe route bij 8/8 niet opslaan, exporteren of navigeren.
- Plannen en bekijken blijven werken.
- Al getelde routes blijven vrij bruikbaar.
- Navigatiereserveringen wanneer 20%-trigger actief is.

### 4. Opslag, verval en downgrade (`ROUTE_PAKKET_02c`)

**Status:** wacht op 02b + Mirror en expliciet downgradebesluit.

Resultaat:
- Maximaal 3 gratis opgeslagen routes.
- 30 dagen bewaartermijn.
- 7 dagen vooraf waarschuwen.
- Herstelbare vervalstatus.
- Vervaltaak eerst dry-run.
- Terugwaarts veilige migratie.

### 5. Admin en fair-usemeting (`ROUTE_PAKKET_02d`)

**Status:** wacht op 02c + Mirror.

Resultaat:
- Admininzicht in telling, opslag, reserveringen en berekeningen.
- Fair use alleen meten en loggen.
- Plannen mag nooit door meetfouten worden vertraagd of geblokkeerd.
- Lege echte uitkomst is toegestaan; geen voorbeelddata.

## Niet in deze keten

- Definitieve route-opmerkingenverdeling Gratis/Go.
- Definitieve verdeling van route onderweg inkorten.
- Routecollecties en themabundels.
- Club-, coach- en ouderprijsmodel.
- Multisport.
