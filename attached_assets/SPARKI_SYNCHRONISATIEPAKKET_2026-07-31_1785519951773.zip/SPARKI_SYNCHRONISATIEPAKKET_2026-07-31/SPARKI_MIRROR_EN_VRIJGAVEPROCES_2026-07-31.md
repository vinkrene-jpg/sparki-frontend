# SPARKI — MIRROR- EN VRIJGAVEPROCES

## Standaardproces

1. René neemt of bevestigt het productbesluit.
2. De opdracht wordt klein, begrensd en machine-toetsbaar gemaakt.
3. Replit bouwt uitsluitend die opdracht.
4. Replit levert bewijs: start-SHA, eind-SHA, gewijzigde bestanden, tests en exitcodes.
5. Mirror test onafhankelijk in DEV Preview en waar nodig via directe API-aanroepen.
6. René geeft de volgende opdracht expliciet vrij.

## Statuswoorden

- `PROVEN_READY`: gebouwd en onafhankelijk bewezen.
- `BUILT_UNPROVEN`: gebouwd, nog niet onafhankelijk bewezen.
- `PARTIAL`: deels aanwezig of niet volledig betrouwbaar.
- `OPEN`: nog niet gebouwd of besloten.
- `DEFERRED`: bewust uitgesteld.

## Browserregels voor Mirror

Mirror gebruikt uitsluitend:
- Sparki DEV Preview;
- relevante Sparki API-endpoints;
- Replit;
- relevante GitHub-pagina's.

Onverwachte externe sites, zoals Buzzy, zijn buiten scope. Mirror stopt of keert terug naar de juiste tab. Dubbele GitHub-tabs worden beperkt tot maximaal één PR-tab en één actuele workflowtab.

## Pakkettestidentiteiten

Er moeten drie DEV Preview-identiteiten zijn:
- Gratis;
- `sparki_go`;
- `sparki_pro`.

Geen van deze identiteiten mag `legacy_unrestricted` gebruiken.

## Vrijgavevoorwaarden

Een volgende opdracht start niet wanneer:
- Mirror niet kon testen;
- tests niet groen zijn;
- een directe server-side omzeiling mogelijk is;
- mock-, seed-, demo- of fallbackdata als echte gebruikersdata verschijnt;
- Replit buiten scope heeft gewijzigd;
- een productbesluit door Replit zelf is ingevuld.
