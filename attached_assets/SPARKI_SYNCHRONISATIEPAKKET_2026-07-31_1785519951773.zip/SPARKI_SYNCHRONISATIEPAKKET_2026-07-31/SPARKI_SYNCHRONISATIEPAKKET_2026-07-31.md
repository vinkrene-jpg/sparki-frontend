# SPARKI — SYNCHRONISATIEPAKKET 31-07-2026

## Doel

Dit pakket brengt de actuele Sparki-besluiten, bouwstatus, pakketkeuzes, Mirror-werkwijze en eerstvolgende stappen weer in lijn.

## Inhoud

1. `SPARKI_MASTER_PLAN_ADDENDUM_2026-07-31.yaml`
2. `SPARKI_DAGKAART_2026-07-31.md`
3. `SPARKI_BESLUITREGISTER_2026-07-31.md`
4. `SPARKI_ROADMAP_ROUTEPAKKET_2026-07-31.md`
5. `SPARKI_MIRROR_EN_VRIJGAVEPROCES_2026-07-31.md`
6. `SPARKI_RELEASESTATUS_2026-07-31.md`
7. `SPARKI_ROUTE_PAKKET_BOUWREEKS_01-02d_v2.md`
8. `SPARKI_functies_pakketten_en_status_2026-07-31.xlsx`

## Belangrijke statusregel

Een productbesluit is niet hetzelfde als gebouwd. Gebouwd is niet hetzelfde als onafhankelijk bewezen. Alleen Mirror-goedgekeurde onderdelen mogen als bewezen worden aangemerkt.

## Autoriteit

- René is producteigenaar en geeft vrij.
- Replit bouwt alleen goedgekeurde, afgebakende opdrachten.
- Mirror controleert onafhankelijk.
- Claude en ChatGPT mogen adviseren en reviewen, maar nemen geen productbesluiten namens René.

## Bronbeperking

Dit pakket is een actuele synchronisatielaag boven op het bestaande masterplan. Het vervangt niet stilzwijgend een nieuwere, niet meegeleverde volledige masterplanversie. Bij samenvoeging geldt: nieuwste expliciete beslissing van René wint.
